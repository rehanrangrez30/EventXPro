<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('volunteer');

// Now backed by real per-volunteer assignments (admin/manage_assignments.php).
$events = $pdo->prepare(
    "SELECT e.event_id, e.title, e.event_date, e.start_time, e.venue,
            va.assignment_role, va.assignment_status,
            (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id AND r.status = 'registered') AS registered_count
     FROM volunteer_event_assignments va
     JOIN events e ON va.event_id = e.event_id
     WHERE va.volunteer_id = ?
     ORDER BY e.event_date ASC"
);
$events->execute([$_SESSION['user_id']]);
$events = $events->fetchAll();

$pageTitle = 'Assigned Events';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">My Assigned Events</h4>
      <p class="text-secondary small mb-4">
        Events the administrator has assigned you to help with.
        <a href="<?= APP_URL ?>/volunteer/tasks.php">View my tasks →</a>
      </p>

      <?php if (empty($events)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">You have no assigned events yet. Check back once the admin assigns you to one.</p>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($events as $ev): ?>
            <div class="col-md-6">
              <div class="ex-card h-100">
                <span class="badge text-bg-primary mb-2"><?= sanitize($ev['assignment_role'] ?: 'General Support') ?></span>
                <h6 class="fw-semibold"><?= sanitize($ev['title']) ?></h6>
                <p class="text-secondary small mb-1">
                  <i class="fa-regular fa-calendar me-1"></i><?= date('d M Y', strtotime($ev['event_date'])) ?>
                  &nbsp;·&nbsp;<i class="fa-regular fa-clock me-1"></i><?= date('h:i A', strtotime($ev['start_time'])) ?>
                </p>
                <p class="text-secondary small mb-0"><i class="fa-solid fa-location-dot me-1"></i><?= sanitize($ev['venue']) ?></p>
                <p class="text-secondary small mt-2 mb-0"><?= (int) $ev['registered_count'] ?> participants registered</p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
