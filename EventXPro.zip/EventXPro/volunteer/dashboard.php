<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('volunteer');

$myActivity = $pdo->prepare(
    "SELECT action, description, created_at FROM activity_logs
     WHERE user_id = ? ORDER BY created_at DESC LIMIT 6"
);
$myActivity->execute([$_SESSION['user_id']]);
$logs = $myActivity->fetchAll();

$assignedStmt = $pdo->prepare("SELECT COUNT(*) FROM volunteer_event_assignments WHERE volunteer_id = ?");
$assignedStmt->execute([$_SESSION['user_id']]);
$myAssignedCount = (int) $assignedStmt->fetchColumn();

$completedStmt = $pdo->prepare("SELECT COUNT(*) FROM volunteer_tasks WHERE assigned_volunteer_id = ? AND task_status = 'completed'");
$completedStmt->execute([$_SESSION['user_id']]);
$tasksCompleted = (int) $completedStmt->fetchColumn();

$pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM volunteer_tasks WHERE assigned_volunteer_id = ? AND task_status != 'completed'");
$pendingStmt->execute([$_SESSION['user_id']]);
$tasksPending = (int) $pendingStmt->fetchColumn();

$pageTitle = 'Volunteer Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Welcome, <?= sanitize($_SESSION['full_name']) ?> 👋</h4>

      <div class="row g-3 mb-4">
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $myAssignedCount ?></div>
            <div class="text-secondary small">Assigned Events</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $tasksCompleted ?></div>
            <div class="text-secondary small">Tasks Completed</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $tasksPending ?></div>
            <div class="text-secondary small">Tasks Pending</div>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-2">Event Preparation</h6>
        <p class="text-secondary small mb-3">
          The administrator assigns you to events and specific tasks.
        </p>
        <a href="<?= APP_URL ?>/volunteer/assigned_events.php" class="btn btn-sm btn-primary">My Assigned Events</a>
        <a href="<?= APP_URL ?>/volunteer/tasks.php" class="btn btn-sm btn-outline-primary">My Tasks</a>
      </div>

      <div class="ex-card">
        <h6 class="fw-semibold mb-3">My Recent Activity</h6>
        <?php if (empty($logs)): ?>
          <p class="text-secondary small mb-0">No activity recorded yet.</p>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($logs as $log): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span><?= sanitize($log['description'] ?? $log['action']) ?></span>
                <span class="text-secondary small"><?= date('d M, H:i', strtotime($log['created_at'])) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
