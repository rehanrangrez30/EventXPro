<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('volunteer');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('volunteer/tasks.php');
    }

    $taskId    = (int) $_POST['task_id'];
    $newStatus = $_POST['task_status'] ?? '';

    if (in_array($newStatus, ['pending', 'in_progress', 'completed'], true)) {
        // Volunteers may only update the status of their own assigned tasks.
        $update = $pdo->prepare(
            'UPDATE volunteer_tasks SET task_status = ? WHERE task_id = ? AND assigned_volunteer_id = ?'
        );
        $update->execute([$newStatus, $taskId, $_SESSION['user_id']]);
        set_flash('success', 'Task status updated.');
    }

    redirect('volunteer/tasks.php');
}

$tasks = $pdo->prepare(
    "SELECT vt.task_id, vt.task_title, vt.task_description, vt.priority, vt.task_status,
            e.title AS event_title, e.event_date
     FROM volunteer_tasks vt
     JOIN events e ON vt.event_id = e.event_id
     WHERE vt.assigned_volunteer_id = ?
     ORDER BY e.event_date ASC"
);
$tasks->execute([$_SESSION['user_id']]);
$tasks = $tasks->fetchAll();

$priorityBadge = ['low' => 'text-bg-secondary', 'medium' => 'text-bg-info', 'high' => 'text-bg-danger'];
$statusBadge   = ['pending' => 'text-bg-secondary', 'in_progress' => 'text-bg-warning', 'completed' => 'text-bg-success'];

$pageTitle = 'My Tasks';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">My Tasks</h4>

      <?php if (empty($tasks)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">No tasks assigned to you yet.</p>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($tasks as $task): ?>
            <div class="col-md-6">
              <div class="ex-card h-100">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <span class="badge <?= $priorityBadge[$task['priority']] ?? 'text-bg-secondary' ?> text-capitalize"><?= sanitize($task['priority']) ?> priority</span>
                  <span class="badge <?= $statusBadge[$task['task_status']] ?? 'text-bg-secondary' ?> text-capitalize"><?= str_replace('_', ' ', sanitize($task['task_status'])) ?></span>
                </div>
                <h6 class="fw-semibold"><?= sanitize($task['task_title']) ?></h6>
                <p class="text-secondary small mb-2"><?= sanitize($task['event_title']) ?> — <?= date('d M Y', strtotime($task['event_date'])) ?></p>
                <?php if ($task['task_description']): ?>
                  <p class="text-secondary small mb-3"><?= sanitize($task['task_description']) ?></p>
                <?php endif; ?>

                <form method="POST" class="d-flex gap-2">
                  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                  <input type="hidden" name="task_id" value="<?= $task['task_id'] ?>">
                  <select name="task_status" class="form-select form-select-sm">
                    <option value="pending" <?= $task['task_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="in_progress" <?= $task['task_status'] === 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="completed" <?= $task['task_status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                  </select>
                  <button type="submit" class="btn btn-sm btn-primary">Update</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
