-- ====================================================================
-- EventX Pro - Ultimate College Event Management System
-- Database Schema (Phase 1 Foundation)
-- Engine: InnoDB | Charset: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ====================================================================

CREATE DATABASE IF NOT EXISTS eventx_pro_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE eventx_pro_db;

-- --------------------------------------------------------------------
-- Table: roles
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    role_id     INT AUTO_INCREMENT PRIMARY KEY,
    role_name   VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles (role_name, description) VALUES
    ('admin',     'Full system access and management'),
    ('organizer', 'Creates and manages events'),
    ('faculty',   'Approves and oversees student activity'),
    ('student',   'Registers and participates in events'),
    ('volunteer', 'Assists with event execution')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- --------------------------------------------------------------------
-- Table: users
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id        INT AUTO_INCREMENT PRIMARY KEY,
    role_id        INT NOT NULL,
    full_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(150) NOT NULL UNIQUE,
    phone          VARCHAR(15)  DEFAULT NULL,
    password_hash  VARCHAR(255) NOT NULL,
    profile_image  VARCHAR(255) DEFAULT NULL,
    department     VARCHAR(100) DEFAULT NULL,
    status         ENUM('active','inactive','banned') NOT NULL DEFAULT 'active',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(role_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: activity_logs (system audit trail)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_logs (
    log_id      INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT DEFAULT NULL,
    action      VARCHAR(150) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    ip_address  VARCHAR(45)  DEFAULT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_logs_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_logs_user (user_id),
    INDEX idx_logs_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- PHASE 3 ADDITIONS
-- Event Management Core: categories, events, registrations
-- Appended only — no Phase 1/2 table is altered or dropped.
-- ====================================================================

-- --------------------------------------------------------------------
-- Table: event_categories
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS event_categories (
    category_id   INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    icon_class    VARCHAR(50) DEFAULT 'fa-calendar',
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO event_categories (category_name, icon_class) VALUES
    ('Technical Seminar', 'fa-microphone'),
    ('Cultural Fest',     'fa-music'),
    ('Sports Event',      'fa-basketball'),
    ('Workshop',          'fa-hands-holding'),
    ('Hackathon',         'fa-laptop-code')
ON DUPLICATE KEY UPDATE icon_class = VALUES(icon_class);

-- --------------------------------------------------------------------
-- Table: events
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS events (
    event_id             INT AUTO_INCREMENT PRIMARY KEY,
    organizer_id         INT NOT NULL,
    category_id          INT DEFAULT NULL,
    title                VARCHAR(150) NOT NULL,
    description          TEXT NOT NULL,
    event_date           DATE NOT NULL,
    start_time           TIME NOT NULL,
    end_time             TIME NOT NULL,
    venue                VARCHAR(150) NOT NULL,
    max_participants     INT NOT NULL DEFAULT 0,
    registration_deadline DATETIME NOT NULL,
    poster_image         VARCHAR(255) DEFAULT NULL,
    status               ENUM('draft','published','cancelled','archived') NOT NULL DEFAULT 'draft',
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_events_organizer FOREIGN KEY (organizer_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_events_category FOREIGN KEY (category_id) REFERENCES event_categories(category_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_events_date (event_date),
    INDEX idx_events_category (category_id),
    INDEX idx_events_organizer (organizer_id),
    INDEX idx_events_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: registrations
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS registrations (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id         INT NOT NULL,
    student_id       INT NOT NULL,
    status           ENUM('registered','cancelled') NOT NULL DEFAULT 'registered',
    registered_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_reg_student FOREIGN KEY (student_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uq_event_student (event_id, student_id),
    INDEX idx_reg_event (event_id),
    INDEX idx_reg_student (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- PHASE 4 ADDITIONS
-- Admin Panel support + Attendance, Certificates, Feedback,
-- Notifications, Volunteer/Faculty Assignments, Settings.
--
-- Column naming intentionally matches the Phase 1-3 convention already
-- in use (user_id, event_id, password_hash, roles lookup table, etc.)
-- instead of the alternate naming in the newer master-prompt revision,
-- so that no existing PHP file needs to change. Appended only — no
-- Phase 1/2/3 table is altered or dropped.
-- ====================================================================

-- --------------------------------------------------------------------
-- Table: login_logs
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_logs (
    log_id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT DEFAULT NULL,
    login_time     DATETIME NOT NULL,
    logout_time    DATETIME DEFAULT NULL,
    login_status   ENUM('success','failed','blocked') NOT NULL DEFAULT 'success',
    ip_address     VARCHAR(45) DEFAULT NULL,
    failure_reason VARCHAR(255) DEFAULT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_loginlogs_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_loginlogs_user (user_id),
    INDEX idx_loginlogs_time (login_time),
    INDEX idx_loginlogs_status (login_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: attendance
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id     INT AUTO_INCREMENT PRIMARY KEY,
    registration_id   INT NOT NULL,
    event_id          INT NOT NULL,
    student_id        INT NOT NULL,
    attendance_status ENUM('present','absent') NOT NULL DEFAULT 'absent',
    check_in_time     DATETIME DEFAULT NULL,
    marked_by         INT DEFAULT NULL,
    remarks           VARCHAR(255) DEFAULT NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_att_registration FOREIGN KEY (registration_id) REFERENCES registrations(registration_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_att_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_att_student FOREIGN KEY (student_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_att_marker FOREIGN KEY (marked_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    UNIQUE KEY uq_attendance_registration (registration_id),
    INDEX idx_att_event (event_id),
    INDEX idx_att_student (student_id),
    INDEX idx_att_status (attendance_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: certificates
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS certificates (
    certificate_id     INT AUTO_INCREMENT PRIMARY KEY,
    registration_id    INT NOT NULL,
    student_id         INT NOT NULL,
    event_id           INT NOT NULL,
    certificate_number VARCHAR(50) NOT NULL UNIQUE,
    verification_code  VARCHAR(100) NOT NULL UNIQUE,
    certificate_type   ENUM('participation','winner','runner_up') NOT NULL DEFAULT 'participation',
    issue_date         DATETIME DEFAULT CURRENT_TIMESTAMP,
    generated_by       INT NOT NULL,
    certificate_status ENUM('generated','revoked') NOT NULL DEFAULT 'generated',
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cert_registration FOREIGN KEY (registration_id) REFERENCES registrations(registration_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_cert_student FOREIGN KEY (student_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_cert_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_cert_generator FOREIGN KEY (generated_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE KEY uq_cert_registration (registration_id),
    INDEX idx_cert_student (student_id),
    INDEX idx_cert_event (event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: feedback
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id      INT AUTO_INCREMENT PRIMARY KEY,
    registration_id  INT NOT NULL,
    student_id       INT NOT NULL,
    event_id         INT NOT NULL,
    overall_rating   TINYINT NOT NULL,
    comment          TEXT DEFAULT NULL,
    feedback_status  ENUM('submitted','hidden') NOT NULL DEFAULT 'submitted',
    submitted_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fb_registration FOREIGN KEY (registration_id) REFERENCES registrations(registration_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_fb_student FOREIGN KEY (student_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_fb_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE KEY uq_fb_student_event (student_id, event_id),
    CONSTRAINT chk_fb_rating CHECK (overall_rating BETWEEN 1 AND 5),
    INDEX idx_fb_event (event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: notifications
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    notification_id   INT AUTO_INCREMENT PRIMARY KEY,
    user_id            INT NOT NULL,
    event_id           INT DEFAULT NULL,
    title              VARCHAR(200) NOT NULL,
    message            TEXT NOT NULL,
    notification_type  ENUM('registration','certificate','announcement','system') NOT NULL DEFAULT 'system',
    is_read            TINYINT(1) NOT NULL DEFAULT 0,
    action_url         VARCHAR(255) DEFAULT NULL,
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_notif_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_notif_user (user_id),
    INDEX idx_notif_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: gallery
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gallery (
    gallery_id    INT AUTO_INCREMENT PRIMARY KEY,
    event_id      INT NOT NULL,
    title         VARCHAR(150) NOT NULL,
    image_path    VARCHAR(255) NOT NULL,
    uploaded_by   INT NOT NULL,
    status        ENUM('active','hidden') NOT NULL DEFAULT 'active',
    uploaded_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_gallery_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_gallery_uploader FOREIGN KEY (uploaded_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_gallery_event (event_id),
    INDEX idx_gallery_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: announcements
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS announcements (
    announcement_id  INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(200) NOT NULL,
    content          TEXT NOT NULL,
    target_audience  ENUM('all','student','faculty','organizer','volunteer') NOT NULL DEFAULT 'all',
    is_pinned        TINYINT(1) NOT NULL DEFAULT 0,
    status           ENUM('draft','published','archived') NOT NULL DEFAULT 'draft',
    created_by       INT NOT NULL,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ann_creator FOREIGN KEY (created_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_ann_status (status),
    INDEX idx_ann_audience (target_audience)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: volunteer_tasks
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS volunteer_tasks (
    task_id             INT AUTO_INCREMENT PRIMARY KEY,
    event_id            INT NOT NULL,
    task_title          VARCHAR(200) NOT NULL,
    task_description    TEXT DEFAULT NULL,
    priority            ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
    task_status         ENUM('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
    assigned_volunteer_id INT DEFAULT NULL,
    created_by          INT NOT NULL,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_task_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_task_volunteer FOREIGN KEY (assigned_volunteer_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_task_creator FOREIGN KEY (created_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_task_event (event_id),
    INDEX idx_task_volunteer (assigned_volunteer_id),
    INDEX idx_task_status (task_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: volunteer_event_assignments
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS volunteer_event_assignments (
    assignment_id     INT AUTO_INCREMENT PRIMARY KEY,
    event_id          INT NOT NULL,
    volunteer_id      INT NOT NULL,
    assigned_by       INT NOT NULL,
    assignment_role   VARCHAR(100) DEFAULT NULL,
    assignment_status ENUM('assigned','completed','cancelled') NOT NULL DEFAULT 'assigned',
    assigned_date     DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vea_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_vea_volunteer FOREIGN KEY (volunteer_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_vea_assigner FOREIGN KEY (assigned_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE KEY uq_vea_event_volunteer (event_id, volunteer_id),
    INDEX idx_vea_event (event_id),
    INDEX idx_vea_volunteer (volunteer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: faculty_event_assignments
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS faculty_event_assignments (
    assignment_id       INT AUTO_INCREMENT PRIMARY KEY,
    event_id            INT NOT NULL,
    faculty_id          INT NOT NULL,
    assigned_by         INT NOT NULL,
    responsibility_type ENUM('coordinator','mentor','evaluator','supervisor') NOT NULL DEFAULT 'coordinator',
    assignment_status   ENUM('assigned','completed','cancelled') NOT NULL DEFAULT 'assigned',
    assigned_date       DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fea_event FOREIGN KEY (event_id) REFERENCES events(event_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_fea_faculty FOREIGN KEY (faculty_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_fea_assigner FOREIGN KEY (assigned_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE KEY uq_fea_event_faculty (event_id, faculty_id),
    INDEX idx_fea_event (event_id),
    INDEX idx_fea_faculty (faculty_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: settings
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
    setting_id    INT AUTO_INCREMENT PRIMARY KEY,
    setting_key    VARCHAR(100) NOT NULL UNIQUE,
    setting_value  TEXT DEFAULT NULL,
    setting_group  VARCHAR(100) NOT NULL DEFAULT 'general',
    description    VARCHAR(255) DEFAULT NULL,
    updated_by     INT DEFAULT NULL,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_settings_updater FOREIGN KEY (updated_by) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO settings (setting_key, setting_value, setting_group, description) VALUES
    ('registration_enabled', 'true',  'events',   'Allow students to register for events site-wide'),
    ('maintenance_mode',     'false', 'general',  'Show a maintenance notice and block public access'),
    ('contact_email',        'support@eventxpro.local', 'general', 'Public contact email shown in the footer'),
    ('contact_phone',        '0000000000', 'general', 'Public contact phone shown in the footer')
ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group);

-- ====================================================================
-- PHASE 6 ADDITIONS
-- Forgot Password, Remember Me, PDF Certificates
-- Appended only — no existing table is dropped or redefined.
-- ====================================================================

-- --------------------------------------------------------------------
-- Table: password_resets
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_resets (
    reset_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    token_hash  VARCHAR(255) NOT NULL,
    expires_at  DATETIME NOT NULL,
    used        TINYINT(1) NOT NULL DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    INDEX idx_reset_user (user_id),
    INDEX idx_reset_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Table: remember_tokens
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS remember_tokens (
    token_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    selector    VARCHAR(24) NOT NULL UNIQUE,
    token_hash  VARCHAR(255) NOT NULL,
    expires_at  DATETIME NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_remember_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    INDEX idx_remember_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- Extend certificates with a PDF file path (additive column only —
-- the existing certificates table definition above is untouched).
-- --------------------------------------------------------------------
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS pdf_path VARCHAR(255) DEFAULT NULL AFTER certificate_status;
