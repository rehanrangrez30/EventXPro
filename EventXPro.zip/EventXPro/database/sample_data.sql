-- ====================================================================
-- EventX Pro - Sample / Demo Data
-- For testing, presentation, and populating dashboards with realistic
-- data. Run AFTER eventx_pro_db.sql has created the schema.
--
-- All demo passwords are: Demo@1234
-- (hashed below with PHP's password_hash() / PASSWORD_DEFAULT - bcrypt)
--
-- Column names match the project's existing schema exactly (user_id,
-- event_id, password_hash, roles lookup table, etc.) — this file only
-- INSERTs into tables that already exist in eventx_pro_db.sql, it does
-- not create or alter any table.
-- ====================================================================

USE eventx_pro_db;

-- --------------------------------------------------------------------
-- Demo Users
-- (roles/event_categories already seeded by eventx_pro_db.sql)
-- --------------------------------------------------------------------
INSERT INTO users (role_id, full_name, email, phone, password_hash, department, status) VALUES
    ((SELECT role_id FROM roles WHERE role_name = 'admin'),
        'System Administrator', 'admin@eventx.demo', '9000000001',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Administration', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'organizer'),
        'Event Coordinator', 'organizer@eventx.demo', '9000000002',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Student Activities', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'faculty'),
        'Dr. Faculty Mentor', 'faculty@eventx.demo', '9000000003',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Computer Engineering', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'volunteer'),
        'Campus Volunteer', 'volunteer@eventx.demo', '9000000004',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Computer Engineering', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'student'),
        'Aarav Shah', 'student1@eventx.demo', '9000000005',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Computer Engineering', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'student'),
        'Diya Patel', 'student2@eventx.demo', '9000000006',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Information Technology', 'active'),
    ((SELECT role_id FROM roles WHERE role_name = 'student'),
        'Kabir Mehta', 'student3@eventx.demo', '9000000007',
        '$2b$10$iEr09Pdcy0ettrTL3U3ZUeSHE0onZi33Udfb9czOj0KPSLyFI2aMC', 'Mechanical Engineering', 'active')
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name);

-- Note: password_hash was generated with bcrypt (10 rounds) for the
-- literal password "Demo@1234" and verified against PHP's password_verify()
-- semantics ($2b$ hashes are accepted by password_verify() the same as $2y$).

-- --------------------------------------------------------------------
-- Demo Events (created by the demo organizer)
-- --------------------------------------------------------------------
INSERT INTO events (organizer_id, category_id, title, description, event_date, start_time, end_time,
                     venue, max_participants, registration_deadline, status) VALUES
    ((SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'),
     (SELECT category_id FROM event_categories WHERE category_name = 'Technical Seminar'),
     'Annual Tech Fest 2026',
     'A campus-wide celebration of technology featuring talks, coding contests and project showcases.',
     DATE_ADD(CURDATE(), INTERVAL 20 DAY), '09:00:00', '17:00:00',
     'Main Auditorium', 150, DATE_ADD(NOW(), INTERVAL 15 DAY), 'published'),

    ((SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'),
     (SELECT category_id FROM event_categories WHERE category_name = 'Workshop'),
     'Web Development Workshop',
     'Hands-on workshop covering HTML, CSS, JavaScript and building a small project from scratch.',
     DATE_ADD(CURDATE(), INTERVAL 10 DAY), '10:00:00', '13:00:00',
     'Computer Lab 3', 60, DATE_ADD(NOW(), INTERVAL 7 DAY), 'published'),

    ((SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'),
     (SELECT category_id FROM event_categories WHERE category_name = 'Cultural Fest'),
     'Cultural Night 2026',
     'An evening of music, dance and drama performances by student clubs.',
     DATE_ADD(CURDATE(), INTERVAL 30 DAY), '18:00:00', '21:00:00',
     'Open Air Theatre', 300, DATE_ADD(NOW(), INTERVAL 25 DAY), 'published'),

    ((SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'),
     (SELECT category_id FROM event_categories WHERE category_name = 'Hackathon'),
     '24-Hour Hackathon',
     'Team-based overnight hackathon solving real-world problem statements.',
     DATE_SUB(CURDATE(), INTERVAL 5 DAY), '09:00:00', '09:00:00',
     'Innovation Center', 100, DATE_SUB(NOW(), INTERVAL 8 DAY), 'archived');

-- --------------------------------------------------------------------
-- Demo Registrations
-- --------------------------------------------------------------------
INSERT INTO registrations (event_id, student_id, status) VALUES
    ((SELECT event_id FROM events WHERE title = 'Annual Tech Fest 2026'),
     (SELECT user_id FROM users WHERE email = 'student1@eventx.demo'), 'registered'),
    ((SELECT event_id FROM events WHERE title = 'Annual Tech Fest 2026'),
     (SELECT user_id FROM users WHERE email = 'student2@eventx.demo'), 'registered'),
    ((SELECT event_id FROM events WHERE title = 'Web Development Workshop'),
     (SELECT user_id FROM users WHERE email = 'student1@eventx.demo'), 'registered'),
    ((SELECT event_id FROM events WHERE title = 'Cultural Night 2026'),
     (SELECT user_id FROM users WHERE email = 'student3@eventx.demo'), 'registered'),
    ((SELECT event_id FROM events WHERE title = '24-Hour Hackathon'),
     (SELECT user_id FROM users WHERE email = 'student2@eventx.demo'), 'registered')
ON DUPLICATE KEY UPDATE status = VALUES(status);

-- --------------------------------------------------------------------
-- Demo Attendance (for the completed/archived hackathon)
-- --------------------------------------------------------------------
INSERT INTO attendance (registration_id, event_id, student_id, attendance_status, check_in_time, marked_by)
SELECT r.registration_id, r.event_id, r.student_id, 'present', NOW(),
       (SELECT user_id FROM users WHERE email = 'organizer@eventx.demo')
FROM registrations r
JOIN events e ON r.event_id = e.event_id
WHERE e.title = '24-Hour Hackathon' AND r.student_id = (SELECT user_id FROM users WHERE email = 'student2@eventx.demo')
ON DUPLICATE KEY UPDATE attendance_status = VALUES(attendance_status);

-- --------------------------------------------------------------------
-- Demo Feedback (for the completed hackathon)
-- --------------------------------------------------------------------
INSERT INTO feedback (registration_id, student_id, event_id, overall_rating, comment)
SELECT r.registration_id, r.student_id, r.event_id, 5, 'Well organized and a great learning experience!'
FROM registrations r
JOIN events e ON r.event_id = e.event_id
WHERE e.title = '24-Hour Hackathon' AND r.student_id = (SELECT user_id FROM users WHERE email = 'student2@eventx.demo')
ON DUPLICATE KEY UPDATE comment = VALUES(comment);

-- --------------------------------------------------------------------
-- Demo Notifications
-- --------------------------------------------------------------------
INSERT INTO notifications (user_id, event_id, title, message, notification_type, action_url) VALUES
    ((SELECT user_id FROM users WHERE email = 'student1@eventx.demo'),
     (SELECT event_id FROM events WHERE title = 'Annual Tech Fest 2026'),
     'Registration Confirmed', 'You have successfully registered for Annual Tech Fest 2026.',
     'registration', 'student/my_registrations.php'),
    ((SELECT user_id FROM users WHERE email = 'student2@eventx.demo'),
     (SELECT event_id FROM events WHERE title = '24-Hour Hackathon'),
     'Certificate Available', 'Your participation certificate for 24-Hour Hackathon is ready.',
     'certificate', 'student/certificates.php');

-- --------------------------------------------------------------------
-- Demo Volunteer Task
-- --------------------------------------------------------------------
INSERT INTO volunteer_tasks (event_id, task_title, task_description, priority, task_status, assigned_volunteer_id, created_by) VALUES
    ((SELECT event_id FROM events WHERE title = 'Annual Tech Fest 2026'),
     'Manage Registration Desk', 'Greet participants and verify registrations at the entrance.',
     'high', 'pending',
     (SELECT user_id FROM users WHERE email = 'volunteer@eventx.demo'),
     (SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'));

-- --------------------------------------------------------------------
-- Demo Activity Log entries
-- --------------------------------------------------------------------
INSERT INTO activity_logs (user_id, action, description) VALUES
    ((SELECT user_id FROM users WHERE email = 'organizer@eventx.demo'), 'event_created', 'Annual Tech Fest 2026'),
    ((SELECT user_id FROM users WHERE email = 'student1@eventx.demo'), 'event_registration', 'Registered for: Annual Tech Fest 2026');

-- ====================================================================
-- Demo login credentials (all use the same password for convenience)
-- ====================================================================
-- admin@eventx.demo      | Demo@1234  | Administrator
-- organizer@eventx.demo  | Demo@1234  | Organizer
-- faculty@eventx.demo    | Demo@1234  | Faculty
-- volunteer@eventx.demo  | Demo@1234  | Volunteer
-- student1@eventx.demo   | Demo@1234  | Student (Aarav Shah)
-- student2@eventx.demo   | Demo@1234  | Student (Diya Patel)
-- student3@eventx.demo   | Demo@1234  | Student (Kabir Mehta)
-- ====================================================================
