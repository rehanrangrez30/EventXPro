<?php
/**
 * EventX Pro - Database Connection
 * Uses PDO with prepared statements throughout the project.
 */

require_once __DIR__ . '/config.php';

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log('Database Connection Failed: ' . $e->getMessage());

    if (APP_ENV === 'development') {
        die('Database connection failed: ' . $e->getMessage());
    }

    die('We are experiencing a technical issue. Please try again later.');
}

// ---------------------------------------------------------------
// Session revocation check (Phase 10)
// If an admin force-ends this session from Admin > Active Sessions,
// login_logs.logout_time gets stamped server-side. Check it on every
// request so a revoked session is actually killed, not just flagged.
// ---------------------------------------------------------------
if (isset($_SESSION['user_id']) && !empty($_SESSION['login_log_id'])) {
    $sessionCheck = $pdo->prepare('SELECT logout_time FROM login_logs WHERE log_id = ?');
    $sessionCheck->execute([$_SESSION['login_log_id']]);
    $sessionRow = $sessionCheck->fetch();

    if ($sessionRow && $sessionRow['logout_time'] !== null) {
        $_SESSION = [];
        session_destroy();
        session_start();
    }
}
// If the user isn't already logged in but holds a valid, unexpired
// remember-me cookie, restore their session automatically.
// ---------------------------------------------------------------
if (!isset($_SESSION['user_id']) && !empty($_COOKIE['eventx_remember'])) {
    $parts = explode(':', $_COOKIE['eventx_remember'], 2);

    if (count($parts) === 2) {
        [$selector, $validator] = $parts;

        $stmt = $pdo->prepare(
            'SELECT rt.user_id, rt.token_hash, rt.expires_at, u.full_name, u.email, u.status, r.role_name
             FROM remember_tokens rt
             JOIN users u ON rt.user_id = u.user_id
             JOIN roles r ON u.role_id = r.role_id
             WHERE rt.selector = ?'
        );
        $stmt->execute([$selector]);
        $tokenRow = $stmt->fetch();

        if ($tokenRow && strtotime($tokenRow['expires_at']) > time()
            && $tokenRow['status'] === 'active'
            && hash_equals($tokenRow['token_hash'], hash('sha256', $validator))
        ) {
            session_regenerate_id(true);
            $_SESSION['user_id']   = $tokenRow['user_id'];
            $_SESSION['full_name'] = $tokenRow['full_name'];
            $_SESSION['email']     = $tokenRow['email'];
            $_SESSION['role_name'] = $tokenRow['role_name'];

            // Log this auto-login too, so it shows up (and can be force-
            // ended) in Admin > Active Sessions just like a manual login.
            $autoLoginLog = $pdo->prepare(
                'INSERT INTO login_logs (user_id, login_time, login_status, ip_address) VALUES (?, NOW(), "success", ?)'
            );
            $autoLoginLog->execute([$tokenRow['user_id'], $_SERVER['REMOTE_ADDR'] ?? null]);
            $_SESSION['login_log_id'] = (int) $pdo->lastInsertId();
        } else {
            // Invalid/expired token: clear the cookie so it isn't retried.
            setcookie('eventx_remember', '', time() - 3600, '/');
        }
    }
}
