<?php
/**
 * EventX Pro - Ultimate College Event Management System
 * Global Application Configuration
 *
 * Store all configurable values here. Never hardcode these values
 * anywhere else in the project.
 */

// ---------------------------------------------------------------
// Application Settings
// ---------------------------------------------------------------
define('APP_NAME', 'EventX Pro');
define('APP_TAGLINE', 'Ultimate College Event Management System');
define('APP_URL', 'http://localhost/EventXPro');
define('APP_ENV', 'development'); // development | production

// ---------------------------------------------------------------
// Timezone
// ---------------------------------------------------------------
date_default_timezone_set('Asia/Kolkata');

// ---------------------------------------------------------------
// Database Settings
// ---------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'eventx_pro_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------
// Upload Settings
// ---------------------------------------------------------------
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5 MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'webp']);

// ---------------------------------------------------------------
// Background Music (user-provided asset — never replace this file)
// ---------------------------------------------------------------
define('BG_MUSIC_FILE', 'assets/audio/donu_donu.mp3');

// ---------------------------------------------------------------
// Email (SMTP) Settings
// ---------------------------------------------------------------
// EventX Pro sends registration confirmation and certificate emails
// using a dependency-free SMTP client (includes/mailer.php) — no
// PHPMailer/Composer required, keeping the project XAMPP-installable
// as-is.
//
// SETUP (Gmail example — free, ~5 minutes):
//   1. On your Google Account: Security > 2-Step Verification > turn ON.
//   2. Security > App Passwords > create one for "Mail" / "Other".
//   3. Google gives you a 16-character password — paste it below as
//      SMTP_PASS (NOT your normal Gmail password).
//   4. Set SMTP_USER to the full Gmail address that generated it.
//
// Any other SMTP provider (Outlook, your college's mail server, etc.)
// works too — just change SMTP_HOST/PORT accordingly.
//
// Until these are filled in, EMAIL_ENABLED stays false and the app
// simply skips sending mail (registration/certificates still work
// normally — email is a bonus notification, not a requirement).
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);                 // 587 = STARTTLS, 465 = SSL
define('SMTP_USER', '');                  // e.g. 'yourcollegeproject@gmail.com'
define('SMTP_PASS', '');                  // 16-character Gmail App Password
define('SMTP_FROM_EMAIL', SMTP_USER);
define('SMTP_FROM_NAME', APP_NAME);
define('EMAIL_ENABLED', SMTP_USER !== '' && SMTP_PASS !== '');

// ---------------------------------------------------------------
// Error Reporting
// ---------------------------------------------------------------
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../docs/error_log.txt');

// ---------------------------------------------------------------
// Central Error Handling & Security Headers (Phase 5)
// ---------------------------------------------------------------
require_once __DIR__ . '/../includes/error_handler.php';

if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

// ---------------------------------------------------------------
// Session Settings (secure defaults)
// ---------------------------------------------------------------
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
