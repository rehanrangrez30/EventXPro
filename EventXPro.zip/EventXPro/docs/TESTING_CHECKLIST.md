# EventX Pro — Testing Checklist

Manual QA checklist for verifying the application before a demo or
submission. Organized by module; check items off against a fresh
install with `sample_data.sql` loaded (see `DEPLOYMENT_GUIDE.md`).

---

## 1. Authentication (`login.php`, `register.php`, `logout.php`, `forgot_password.php`, `reset_password.php`)

- [ ] Register a new student with a weak password (e.g. `abc123`) → rejected with a clear complexity message
- [ ] Register with a valid strong password → account created, redirected to login
- [ ] Register with an email already in use → duplicate-email error, no second row inserted
- [ ] Log in with correct credentials → redirected to the correct role's dashboard (test admin, organizer, faculty, volunteer, student)
- [ ] Log in with wrong password → generic "invalid credentials" error (doesn't reveal whether the email exists)
- [ ] Fail login 5 times in a row → 6th attempt blocked for 15 minutes, event recorded in `logs/security.log`
- [ ] Check "Remember me" at login, close browser, reopen → still logged in
- [ ] "Forgot password" → enter a registered email → reset link/token generated
- [ ] Use the reset link within its validity window → new password accepted, old password no longer works
- [ ] Use an expired/already-used reset token → rejected
- [ ] Log out → session destroyed, protected pages redirect to login afterward
- [ ] Try to open `/admin/dashboard.php` while logged out → redirected to login
- [ ] Try to open `/admin/dashboard.php` while logged in as a student → `errors/403.php`

## 2. Public Pages (`index.php`, `events.php`, `event_details.php`, `gallery.php`, `about.php`, `contact.php`)

- [ ] Homepage stats (published events, users) match actual DB counts
- [ ] "Featured Upcoming Events" only shows published, future-dated events
- [ ] `events.php` search matches title, venue, description, and category name
- [ ] Searching a term with no matches shows the "you might be interested in" fallback, not a dead end
- [ ] Category filter narrows results correctly
- [ ] `event_details.php` "You Might Also Like" shows same-category events, excludes the current one
- [ ] Registering while logged out → redirected to login, then back to the event
- [ ] Registering after the deadline / when full → blocked with a clear message, no duplicate DB row
- [ ] Cancelling a registration → status flips to `cancelled`, seat becomes available again
- [ ] Gallery images lazy-load (check Network tab — off-screen images shouldn't fetch immediately)

## 3. Student Module (`student/*.php`)

- [ ] Dashboard stat cards (Events Registered, Certificates Earned, Pending Feedback) match real counts, not hardcoded zeros
- [ ] "Recommended for You" only appears after the student has at least one registration, and suggests same-category events they haven't joined
- [ ] `my_registrations.php` lists all registrations with correct status badges
- [ ] `certificates.php` only shows certificates with `certificate_status = 'generated'`; download link opens a real PDF
- [ ] `feedback.php` only allows feedback for past events the student attended, and blocks a second submission for the same event
- [ ] Profile update (name/phone/department) saves and reflects immediately; email field is not editable

## 4. Organizer Module (`organizer/*.php`)

- [ ] `event_form.php` rejects an end time before the start time, and a registration deadline after the event start
- [ ] New events save as `draft`; only appear publicly after "Publish" from `manage_events.php`
- [ ] Organizer only sees/edits their own events, not other organizers'
- [ ] `attendance.php` — marking present/absent saves per participant, duplicate marking is prevented
- [ ] `certificates.php` — generates a real downloadable PDF (not just a DB row) with a working verification code

## 5. Faculty / Volunteer Modules

- [ ] `faculty/assigned_events.php` shows only events an admin has actually assigned to that faculty member (not every event campus-wide)
- [ ] `faculty/attendance_review.php` is read-only — no edit controls
- [ ] `volunteer/assigned_events.php` shows only that volunteer's assigned events
- [ ] `volunteer/tasks.php` — a volunteer can update status on their own tasks, not others'

## 6. Admin Module (`admin/*.php`)

- [ ] `manage_users.php` — activate/deactivate a user, confirm they can/can't log in accordingly
- [ ] `manage_events.php` — admin can view/cancel any event across all organizers
- [ ] `manage_categories.php` — CRUD works; deleting a category in use is handled gracefully (not a hard DB error)
- [ ] `manage_gallery.php` — upload rejects non-image files and oversized files; accepted images appear on `gallery.php`
- [ ] `manage_announcements.php` — a pinned + published announcement targeted at "students" shows in the banner for a student, not for a faculty account
- [ ] `manage_assignments.php` — assigning a faculty/volunteer to an event makes it appear on their respective dashboard immediately
- [ ] `activity_logs.php` — filter by action keyword returns matching rows only
- [ ] `active_sessions.php` — "Force Logout" on another user's session actually signs them out on their next request
- [ ] `backup.php` — downloaded `.sql` file re-imports cleanly into a fresh empty database via phpMyAdmin
- [ ] `export.php` — CSV downloads open correctly in Excel/Sheets with correct headers
- [ ] Dashboard charts (registrations trend, events by category) reflect real data and update after adding a new event/registration

## 7. Notifications & Chatbot

- [ ] `notifications.php` — registering for an event creates a notification for that student
- [ ] Unread notifications are visually distinct from read ones; marking as read persists
- [ ] Chatbot widget responds sensibly to: "how do I register", "forgot password", "certificate", and a live query like "how many events are open"
- [ ] Chatbot gives a graceful fallback for a nonsense/unrelated message (no PHP error, no blank response)

## 8. Security

- [ ] Every form (login, register, event create, profile update, etc.) rejects submission with a missing/invalid CSRF token
- [ ] Attempting SQL-injection-style input in a search box (e.g. `' OR '1'='1`) is treated as a literal string, not executed
- [ ] Attempting to view another student's registration by guessing an ID in the URL is blocked or shows only that student's own data
- [ ] `config/config.php` and other files under `config/`/`includes/` are not directly downloadable/viewable via the browser
- [ ] With `APP_ENV = 'production'`, a forced DB error shows a generic message, not a raw SQL/stack trace

## 9. PWA & Cross-Device

- [ ] Manifest installs correctly (Chrome: address-bar install icon or the in-app banner)
- [ ] After first load, disconnect network and reload a previously-visited static asset (CSS/JS/icon) — still loads from cache
- [ ] Disconnect network and navigate to a new page — `offline.html` shows instead of a browser error page
- [ ] Site is usable (no horizontal scroll, tap targets large enough) at common breakpoints: 375px (mobile), 768px (tablet), 1280px (desktop)
- [ ] Dark mode toggle works and persists across pages and reloads

---

## Reporting a Bug

When something fails, note: the exact page URL, the account/role used,
the steps taken, and — if possible — the corresponding line(s) in
`logs/error.log` or `logs/security.log` (with `APP_ENV` temporarily set
to `development` to see full error detail).
