# EventX Pro — Deployment Guide (XAMPP / Local Server)

This guide walks through deploying EventX Pro from a fresh XAMPP install
to a fully working local site, plus the checks worth running before a
diploma presentation or demo.

---

## 1. Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| XAMPP | Apache + MySQL + PHP 8.0+ | https://www.apachefriends.org |
| Browser | Chrome or Edge (recommended) | For PWA install-prompt support |
| Disk space | ~50 MB | Project + uploads + backups |

No Node.js, Composer, or Docker is required — everything runs on
XAMPP's bundled Apache/MySQL/PHP.

---

## 2. Install Steps

1. **Start services** — open the XAMPP Control Panel and start
   **Apache** and **MySQL**.
2. **Copy the project** — extract the `EventXPro` folder directly into
   `C:\xampp\htdocs\` (Windows) or `/Applications/XAMPP/htdocs/`
   (macOS), so the path is `htdocs/EventXPro/`.
3. **Create the database** — open `http://localhost/phpmyadmin`, click
   **Import**, choose `database/eventx_pro_db.sql`, and run it. This
   creates the `eventx_pro_db` database, all 20 tables, and default
   lookup data (roles, event categories).
4. **(Optional) Load demo data** — import `database/sample_data.sql`
   the same way, *after* step 3. This adds 7 demo accounts and sample
   events/registrations so dashboards aren't empty for a demo.
5. **Check `config/config.php`** — the defaults (`DB_HOST=localhost`,
   `DB_USER=root`, `DB_PASS=''`, `APP_URL=http://localhost/EventXPro`)
   match a stock XAMPP install. Update `DB_PASS` if your MySQL root
   user has a password, and update `APP_URL` if the folder name or
   port differs.
6. **Set upload folder permissions** — `assets/uploads/` (and its
   `certificates/`, `gallery/`, `profile/` subfolders, created
   automatically on first upload) must be writable by Apache. On
   Windows/XAMPP this is usually already fine; on macOS/Linux run:
   ```
   chmod -R 775 assets/uploads
   ```
7. **Open the site** — `http://localhost/EventXPro/index.php`.

---

## 3. First Login

If you imported `sample_data.sql`, use any of these (password for all:
`Demo@1234`):

| Role | Email |
|---|---|
| Admin | admin@eventx.demo |
| Organizer | organizer@eventx.demo |
| Faculty | faculty@eventx.demo |
| Volunteer | volunteer@eventx.demo |
| Student | student1@eventx.demo |

Otherwise, register a new account from `register.php` — the first
admin account must be created manually by changing a user's `role_id`
directly in `phpMyAdmin` (Admin role is intentionally not selectable
from the public registration form).

---

## 4. Verifying the Deployment

Run through this quickly after any fresh install:

- [ ] Homepage loads with hero section and live stats (`index.php`)
- [ ] Background music player appears bottom-right and plays/pauses
- [ ] Register a student account → redirected to login with success message
- [ ] Log in → redirected to the correct role dashboard
- [ ] Dark mode toggle persists after page reload
- [ ] Browse Events (`events.php`) shows published events, search/filter work
- [ ] `admin/dashboard.php` charts render (Chart.js) — needs at least a
      few events/registrations to show non-empty data (use sample data)
- [ ] Chatbot widget (bottom-left/right bubble) responds to a message
- [ ] On Chrome, an "Install EventX Pro" banner appears after a few
      seconds of browsing (PWA install prompt)

If any of these fail, see **Troubleshooting** below.

---

## 5. Troubleshooting

**Blank page / "technical issue" message**
Set `APP_ENV` to `'development'` in `config/config.php` temporarily to
see the real PHP/PDO error, then check `docs/../logs/error.log`.

**"Database connection failed"**
Double-check `DB_HOST`/`DB_USER`/`DB_PASS`/`DB_NAME` in
`config/config.php` against your actual MySQL credentials, and confirm
MySQL is running in the XAMPP Control Panel.

**Images/certificates fail to upload**
Check that `assets/uploads/` is writable (see step 6 above), and that
the file is under `MAX_UPLOAD_SIZE` (5 MB by default, in
`config/config.php`) and an allowed type (`jpg`, `jpeg`, `png`, `webp`).

**Background music doesn't autoplay**
This is expected — modern browsers block autoplay with sound until the
user interacts with the page. The floating "Play Music" control handles
this; it's not a bug.

**PWA install banner never appears**
Chrome only shows it over `http://localhost` (allowed as a secure
context) after some engagement signals (a few seconds on-page, or a
second visit). It won't appear in Firefox (no `beforeinstallprompt`
support) — that's a browser limitation, not a project bug.

**Certificates PDF is blank/corrupt**
Confirm `assets/uploads/certificates/` exists and is writable;
`includes/pdf_lib.php` writes directly to that path.

**Locked out after failed logins**
Brute-force protection blocks an IP for 15 minutes after 5 failed
attempts (see `logs/security.log`). Wait, or clear old rows from
`login_logs` for that IP in phpMyAdmin during testing.

---

## 6. Backing Up

Use **Admin → Database Backup** in the app (generates a full
structure + data `.sql` dump via pure PHP/PDO — works even if
`shell_exec()`/`mysqldump` is disabled on your XAMPP install), or
export manually via phpMyAdmin's **Export** tab.

---

## 7. Moving to a Different Path/Port

If you rename the project folder or run XAMPP on a non-default port,
update **only** `APP_URL` in `config/config.php` — every page and
asset link in the project derives from that single constant, so
nothing else needs to change.

---

## 8. Email Setup (Optional — Registration & Certificate Emails)

EventX Pro sends a registration confirmation email and a certificate
email (with the PDF attached) via a built-in, dependency-free SMTP
client — no PHPMailer/Composer needed. **This is optional** — until
configured, the app simply skips sending mail and everything else
(registration, certificates) works exactly the same.

To enable it with a free Gmail account:

1. Go to your Google Account → **Security** → turn on **2-Step
   Verification** (required for the next step).
2. Still under Security → **App Passwords** → create one for
   *Mail* / *Other (custom name)* → Google shows you a 16-character
   password (with spaces — remove them when pasting).
3. Open `config/config.php` and fill in:
   ```php
   define('SMTP_USER', 'yourcollegeproject@gmail.com');
   define('SMTP_PASS', 'the16characterapppassword');
   ```
4. That's it — `EMAIL_ENABLED` turns on automatically once both are
   non-empty. Test by registering for an event with a real email
   address you can check.

If email doesn't arrive, check `logs/error.log` for lines starting
with `SMTP` — common causes are 2-Step Verification not actually being
on, or pasting the regular Gmail password instead of the App Password.
