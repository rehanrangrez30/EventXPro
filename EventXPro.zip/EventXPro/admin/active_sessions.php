<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

// Force-logout a session: stamp logout_time so config/db.php's revocation
// check kills it on that user's very next request.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('admin/active_sessions.php');
    }

    $logId = (int) $_POST['log_id'];
    $upd = $pdo->prepare('UPDATE login_logs SET logout_time = NOW() WHERE log_id = ? AND logout_time IS NULL');
    $upd->execute([$logId]);

    $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
    $logStmt->execute([$_SESSION['user_id'], 'force_logout', 'Revoked login_logs #' . $logId, $_SERVER['REMOTE_ADDR'] ?? null]);

    set_flash('success', 'Session ended. It will be signed out on its next request.');
    redirect('admin/active_sessions.php');
}

// "Active" = successful logins with no logout_time yet — the same signal
// config/db.php checks to decide whether a session is still valid.
$sessions = $pdo->query(
    "SELECT l.log_id, l.login_time, l.ip_address, u.full_name, u.email, r.role_name
     FROM login_logs l
     JOIN users u ON l.user_id = u.user_id
     JOIN roles r ON u.role_id = r.role_id
     WHERE l.login_status = 'success' AND l.logout_time IS NULL
     ORDER BY l.login_time DESC
     LIMIT 100"
)->fetchAll();

$pageTitle = 'Active Sessions';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-2">Active Sessions</h4>
      <p class="text-secondary small mb-4">
        Everyone currently signed in (no logout recorded yet). Forcing a
        logout ends that session on its next page load — it does not
        require the user's device to be online right now.
      </p>

      <?php if (empty($sessions)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No active sessions right now.</p></div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">User</th>
                  <th>Role</th>
                  <th>Signed in</th>
                  <th>IP Address</th>
                  <th class="text-end pe-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($sessions as $s): ?>
                  <tr>
                    <td class="ps-4">
                      <div class="fw-semibold"><?= sanitize($s['full_name']) ?></div>
                      <div class="text-secondary small"><?= sanitize($s['email']) ?></div>
                    </td>
                    <td><span class="badge text-bg-secondary text-capitalize"><?= sanitize($s['role_name']) ?></span></td>
                    <td><?= date('d M Y, h:i A', strtotime($s['login_time'])) ?></td>
                    <td><?= sanitize($s['ip_address'] ?? '—') ?></td>
                    <td class="text-end pe-4">
                      <?php if ((int) $s['log_id'] === (int) ($_SESSION['login_log_id'] ?? 0)): ?>
                        <span class="badge text-bg-success">This session</span>
                      <?php else: ?>
                        <form method="POST" class="d-inline" onsubmit="return confirm('End this session? The user will be signed out on their next request.');">
                          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                          <input type="hidden" name="log_id" value="<?= (int) $s['log_id'] ?>">
                          <button type="submit" class="btn btn-sm btn-outline-danger">Force Logout</button>
                        </form>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
