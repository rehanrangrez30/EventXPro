<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }

    if (isset($_POST['add_category']) && empty($errors)) {
        $name = trim($_POST['category_name'] ?? '');
        $icon = trim($_POST['icon_class'] ?? '') ?: 'fa-calendar';

        if (strlen($name) < 2) {
            $errors[] = 'Category name must be at least 2 characters.';
        } else {
            $check = $pdo->prepare('SELECT category_id FROM event_categories WHERE category_name = ?');
            $check->execute([$name]);
            if ($check->fetch()) {
                $errors[] = 'A category with this name already exists.';
            } else {
                $insert = $pdo->prepare('INSERT INTO event_categories (category_name, icon_class) VALUES (?, ?)');
                $insert->execute([$name, $icon]);
                set_flash('success', 'Category "' . $name . '" created.');
                redirect('admin/manage_categories.php');
            }
        }
    }

    if (isset($_POST['toggle_id']) && empty($errors)) {
        $toggle = $pdo->prepare('UPDATE event_categories SET is_active = NOT is_active WHERE category_id = ?');
        $toggle->execute([(int) $_POST['toggle_id']]);
        redirect('admin/manage_categories.php');
    }
}

$categories = $pdo->query(
    "SELECT c.category_id, c.category_name, c.icon_class, c.is_active,
            (SELECT COUNT(*) FROM events e WHERE e.category_id = c.category_id) AS event_count
     FROM event_categories c ORDER BY c.category_name ASC"
)->fetchAll();

$pageTitle = 'Manage Categories';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Manage Event Categories</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">Add New Category</h6>
        <form method="POST" class="row g-2">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <div class="col-md-6">
            <input type="text" name="category_name" class="form-control" placeholder="Category name (e.g. Gaming)" required>
          </div>
          <div class="col-md-4">
            <input type="text" name="icon_class" class="form-control" placeholder="Font Awesome icon (e.g. fa-gamepad)">
          </div>
          <div class="col-md-2">
            <button type="submit" name="add_category" value="1" class="btn btn-primary w-100">Add</button>
          </div>
        </form>
      </div>

      <div class="ex-card p-0">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th class="ps-4">Icon</th>
                <th>Category</th>
                <th>Events Using It</th>
                <th>Status</th>
                <th class="text-end pe-4">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($categories as $cat): ?>
                <tr>
                  <td class="ps-4"><i class="fa-solid <?= sanitize($cat['icon_class']) ?> text-primary"></i></td>
                  <td><?= sanitize($cat['category_name']) ?></td>
                  <td><?= (int) $cat['event_count'] ?></td>
                  <td>
                    <span class="badge <?= $cat['is_active'] ? 'text-bg-success' : 'text-bg-secondary' ?>">
                      <?= $cat['is_active'] ? 'Active' : 'Inactive' ?>
                    </span>
                  </td>
                  <td class="text-end pe-4">
                    <form method="POST" class="d-inline">
                      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                      <input type="hidden" name="toggle_id" value="<?= $cat['category_id'] ?>">
                      <button type="submit" class="btn btn-sm btn-outline-secondary">
                        <?= $cat['is_active'] ? 'Deactivate' : 'Activate' ?>
                      </button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
