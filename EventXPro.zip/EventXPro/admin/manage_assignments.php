<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('admin/manage_assignments.php');
    }

    $action = $_POST['form_action'] ?? '';

    if ($action === 'assign_faculty') {
        $eventId   = (int) $_POST['event_id'];
        $facultyId = (int) $_POST['faculty_id'];
        $resp      = $_POST['responsibility_type'] ?? 'coordinator';

        $stmt = $pdo->prepare(
            'INSERT INTO faculty_event_assignments (event_id, faculty_id, assigned_by, responsibility_type)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE responsibility_type = VALUES(responsibility_type), assignment_status = "assigned"'
        );
        $stmt->execute([$eventId, $facultyId, $_SESSION['user_id'], $resp]);

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], 'faculty_assigned', "Faculty #$facultyId assigned to event #$eventId", $_SERVER['REMOTE_ADDR'] ?? null]);

        set_flash('success', 'Faculty member assigned to the event.');
    } elseif ($action === 'assign_volunteer') {
        $eventId     = (int) $_POST['event_id'];
        $volunteerId = (int) $_POST['volunteer_id'];
        $role        = trim($_POST['assignment_role'] ?? '');

        $stmt = $pdo->prepare(
            'INSERT INTO volunteer_event_assignments (event_id, volunteer_id, assigned_by, assignment_role)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE assignment_role = VALUES(assignment_role), assignment_status = "assigned"'
        );
        $stmt->execute([$eventId, $volunteerId, $_SESSION['user_id'], $role ?: null]);

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], 'volunteer_assigned', "Volunteer #$volunteerId assigned to event #$eventId", $_SERVER['REMOTE_ADDR'] ?? null]);

        set_flash('success', 'Volunteer assigned to the event.');
    } elseif ($action === 'remove_faculty') {
        $pdo->prepare('DELETE FROM faculty_event_assignments WHERE assignment_id = ?')->execute([(int) $_POST['assignment_id']]);
        set_flash('success', 'Faculty assignment removed.');
    } elseif ($action === 'remove_volunteer') {
        $pdo->prepare('DELETE FROM volunteer_event_assignments WHERE assignment_id = ?')->execute([(int) $_POST['assignment_id']]);
        set_flash('success', 'Volunteer assignment removed.');
    }

    redirect('admin/manage_assignments.php');
}

$events     = $pdo->query("SELECT event_id, title, event_date FROM events WHERE status != 'archived' ORDER BY event_date DESC")->fetchAll();
$facultyList   = $pdo->query("SELECT u.user_id, u.full_name FROM users u JOIN roles r ON u.role_id = r.role_id WHERE r.role_name = 'faculty' AND u.status = 'active' ORDER BY u.full_name")->fetchAll();
$volunteerList = $pdo->query("SELECT u.user_id, u.full_name FROM users u JOIN roles r ON u.role_id = r.role_id WHERE r.role_name = 'volunteer' AND u.status = 'active' ORDER BY u.full_name")->fetchAll();

$currentFaculty = $pdo->query(
    "SELECT fa.assignment_id, fa.responsibility_type, fa.assignment_status, e.title AS event_title, u.full_name
     FROM faculty_event_assignments fa
     JOIN events e ON fa.event_id = e.event_id
     JOIN users u ON fa.faculty_id = u.user_id
     ORDER BY e.event_date DESC"
)->fetchAll();

$currentVolunteers = $pdo->query(
    "SELECT va.assignment_id, va.assignment_role, va.assignment_status, e.title AS event_title, u.full_name
     FROM volunteer_event_assignments va
     JOIN events e ON va.event_id = e.event_id
     JOIN users u ON va.volunteer_id = u.user_id
     ORDER BY e.event_date DESC"
)->fetchAll();

$pageTitle = 'Faculty & Volunteer Assignments';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Faculty &amp; Volunteer Assignments</h4>

      <div class="row g-4 mb-4">
        <div class="col-md-6">
          <div class="ex-card h-100">
            <h6 class="fw-semibold mb-3"><i class="fa-solid fa-chalkboard-user text-primary me-2"></i>Assign Faculty</h6>
            <form method="POST">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="form_action" value="assign_faculty">
              <div class="mb-2">
                <select name="event_id" class="form-select" required>
                  <option value="">Select event...</option>
                  <?php foreach ($events as $ev): ?>
                    <option value="<?= $ev['event_id'] ?>"><?= sanitize($ev['title']) ?> (<?= date('d M Y', strtotime($ev['event_date'])) ?>)</option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="mb-2">
                <select name="faculty_id" class="form-select" required>
                  <option value="">Select faculty...</option>
                  <?php foreach ($facultyList as $f): ?>
                    <option value="<?= $f['user_id'] ?>"><?= sanitize($f['full_name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="mb-3">
                <select name="responsibility_type" class="form-select">
                  <option value="coordinator">Coordinator</option>
                  <option value="mentor">Mentor</option>
                  <option value="evaluator">Evaluator</option>
                  <option value="supervisor">Supervisor</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary btn-sm w-100">Assign Faculty</button>
            </form>
          </div>
        </div>

        <div class="col-md-6">
          <div class="ex-card h-100">
            <h6 class="fw-semibold mb-3"><i class="fa-solid fa-hands-helping text-primary me-2"></i>Assign Volunteer</h6>
            <form method="POST">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="form_action" value="assign_volunteer">
              <div class="mb-2">
                <select name="event_id" class="form-select" required>
                  <option value="">Select event...</option>
                  <?php foreach ($events as $ev): ?>
                    <option value="<?= $ev['event_id'] ?>"><?= sanitize($ev['title']) ?> (<?= date('d M Y', strtotime($ev['event_date'])) ?>)</option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="mb-2">
                <select name="volunteer_id" class="form-select" required>
                  <option value="">Select volunteer...</option>
                  <?php foreach ($volunteerList as $v): ?>
                    <option value="<?= $v['user_id'] ?>"><?= sanitize($v['full_name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="mb-3">
                <input type="text" name="assignment_role" class="form-control" placeholder="Role (e.g. Registration Desk)">
              </div>
              <button type="submit" class="btn btn-primary btn-sm w-100">Assign Volunteer</button>
            </form>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4 p-0">
        <div class="p-3 pb-0"><h6 class="fw-semibold">Current Faculty Assignments</h6></div>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th class="ps-4">Faculty</th><th>Event</th><th>Role</th><th>Status</th><th class="pe-4 text-end">Action</th></tr></thead>
            <tbody>
              <?php if (empty($currentFaculty)): ?>
                <tr><td colspan="5" class="text-center text-secondary py-4">No faculty assignments yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($currentFaculty as $fa): ?>
                <tr>
                  <td class="ps-4"><?= sanitize($fa['full_name']) ?></td>
                  <td><?= sanitize($fa['event_title']) ?></td>
                  <td class="text-capitalize"><?= sanitize($fa['responsibility_type']) ?></td>
                  <td><span class="badge text-bg-info text-capitalize"><?= sanitize($fa['assignment_status']) ?></span></td>
                  <td class="pe-4 text-end">
                    <form method="POST" class="d-inline" onsubmit="return confirm('Remove this assignment?');">
                      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                      <input type="hidden" name="form_action" value="remove_faculty">
                      <input type="hidden" name="assignment_id" value="<?= $fa['assignment_id'] ?>">
                      <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="ex-card p-0">
        <div class="p-3 pb-0"><h6 class="fw-semibold">Current Volunteer Assignments</h6></div>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th class="ps-4">Volunteer</th><th>Event</th><th>Role</th><th>Status</th><th class="pe-4 text-end">Action</th></tr></thead>
            <tbody>
              <?php if (empty($currentVolunteers)): ?>
                <tr><td colspan="5" class="text-center text-secondary py-4">No volunteer assignments yet.</td></tr>
              <?php endif; ?>
              <?php foreach ($currentVolunteers as $va): ?>
                <tr>
                  <td class="ps-4"><?= sanitize($va['full_name']) ?></td>
                  <td><?= sanitize($va['event_title']) ?></td>
                  <td><?= sanitize($va['assignment_role'] ?: '—') ?></td>
                  <td><span class="badge text-bg-info text-capitalize"><?= sanitize($va['assignment_status']) ?></span></td>
                  <td class="pe-4 text-end">
                    <form method="POST" class="d-inline" onsubmit="return confirm('Remove this assignment?');">
                      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                      <input type="hidden" name="form_action" value="remove_volunteer">
                      <input type="hidden" name="assignment_id" value="<?= $va['assignment_id'] ?>">
                      <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
