<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['event_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('admin/manage_events.php');
    }

    $eventId = (int) $_POST['event_id'];
    $action = $_POST['action'];
    $statusMap = ['cancel' => 'cancelled', 'archive' => 'archived', 'publish' => 'published'];

    if (isset($statusMap[$action])) {
        $upd = $pdo->prepare('UPDATE events SET status = ? WHERE event_id = ?');
        $upd->execute([$statusMap[$action], $eventId]);

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], 'admin_event_' . $action, 'Event #' . $eventId . ' set to ' . $statusMap[$action], $_SERVER['REMOTE_ADDR'] ?? null]);

        set_flash('success', 'Event status updated to ' . $statusMap[$action] . '.');
    }
    redirect('admin/manage_events.php');
}

$events = $pdo->query(
    "SELECT e.event_id, e.title, e.event_date, e.status, u.full_name AS organizer_name,
            (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id AND r.status = 'registered') AS registered_count
     FROM events e LEFT JOIN users u ON e.organizer_id = u.user_id
     ORDER BY e.event_date DESC"
)->fetchAll();

$statusBadge = ['draft' => 'text-bg-secondary', 'published' => 'text-bg-success', 'cancelled' => 'text-bg-danger', 'archived' => 'text-bg-dark'];

$pageTitle = 'Manage Events';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">All Events (Platform-Wide)</h4>
        <a href="<?= APP_URL ?>/admin/export.php?type=events" class="btn btn-outline-secondary btn-sm">
          <i class="fa-solid fa-file-csv me-1"></i>Export CSV
        </a>
      </div>

      <?php if (empty($events)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No events have been created yet.</p></div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Title</th>
                  <th>Organizer</th>
                  <th>Date</th>
                  <th>Regs</th>
                  <th>Status</th>
                  <th class="text-end pe-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($events as $ev): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($ev['title']) ?></td>
                    <td><?= sanitize($ev['organizer_name'] ?? 'N/A') ?></td>
                    <td><?= date('d M Y', strtotime($ev['event_date'])) ?></td>
                    <td><?= (int) $ev['registered_count'] ?></td>
                    <td><span class="badge <?= $statusBadge[$ev['status']] ?? 'text-bg-secondary' ?> text-capitalize"><?= sanitize($ev['status']) ?></span></td>
                    <td class="text-end pe-4">
                      <form method="POST" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="event_id" value="<?= $ev['event_id'] ?>">
                        <?php if ($ev['status'] === 'published'): ?>
                          <button type="submit" name="action" value="cancel" class="btn btn-sm btn-outline-warning">Cancel</button>
                        <?php endif; ?>
                        <?php if (in_array($ev['status'], ['cancelled', 'published'], true)): ?>
                          <button type="submit" name="action" value="archive" class="btn btn-sm btn-outline-dark">Archive</button>
                        <?php endif; ?>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
