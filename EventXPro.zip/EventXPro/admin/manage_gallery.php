<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'upload' && empty($errors)) {
        $eventId = (int) ($_POST['event_id'] ?? 0);
        $title   = trim($_POST['title'] ?? '');

        if ($eventId <= 0) {
            $errors[] = 'Please select an event.';
        }
        if ($title === '') {
            $errors[] = 'Please give the photo a short title.';
        }
        if (empty($_FILES['image']['name'])) {
            $errors[] = 'Please choose an image file to upload.';
        }

        if (empty($errors)) {
            $file = $_FILES['image'];
            $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if ($file['error'] !== UPLOAD_ERR_OK) {
                $errors[] = 'Upload failed. Please try again.';
            } elseif (!in_array($ext, ALLOWED_IMAGE_TYPES, true)) {
                $errors[] = 'Only ' . implode(', ', ALLOWED_IMAGE_TYPES) . ' files are allowed.';
            } elseif ($file['size'] > MAX_UPLOAD_SIZE) {
                $errors[] = 'Image is too large. Maximum size is 5 MB.';
            } elseif (!getimagesize($file['tmp_name'])) {
                $errors[] = 'The uploaded file is not a valid image.';
            }

            if (empty($errors)) {
                $galleryDir = UPLOAD_DIR . 'gallery/';
                if (!is_dir($galleryDir)) {
                    mkdir($galleryDir, 0755, true);
                }
                $safeName = 'gallery_' . bin2hex(random_bytes(8)) . '.' . $ext;
                if (move_uploaded_file($file['tmp_name'], $galleryDir . $safeName)) {
                    $relativePath = 'assets/uploads/gallery/' . $safeName;
                    $insert = $pdo->prepare(
                        'INSERT INTO gallery (event_id, title, image_path, uploaded_by) VALUES (?, ?, ?, ?)'
                    );
                    $insert->execute([$eventId, $title, $relativePath, $_SESSION['user_id']]);

                    $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
                    $logStmt->execute([$_SESSION['user_id'], 'gallery_upload', $title, $_SERVER['REMOTE_ADDR'] ?? null]);

                    set_flash('success', 'Photo uploaded to the gallery.');
                    redirect('admin/manage_gallery.php');
                } else {
                    $errors[] = 'Could not save the uploaded file. Please try again.';
                }
            }
        }
    } elseif ($formAction === 'toggle' && empty($errors)) {
        $galleryId = (int) $_POST['gallery_id'];
        $pdo->prepare("UPDATE gallery SET status = IF(status = 'active', 'hidden', 'active') WHERE gallery_id = ?")
            ->execute([$galleryId]);
        redirect('admin/manage_gallery.php');
    } elseif ($formAction === 'delete' && empty($errors)) {
        $galleryId = (int) $_POST['gallery_id'];
        $photo = $pdo->prepare('SELECT image_path FROM gallery WHERE gallery_id = ?');
        $photo->execute([$galleryId]);
        $path = $photo->fetchColumn();

        $pdo->prepare('DELETE FROM gallery WHERE gallery_id = ?')->execute([$galleryId]);

        if ($path) {
            $fullPath = __DIR__ . '/../' . $path;
            if (is_file($fullPath)) {
                @unlink($fullPath);
            }
        }
        set_flash('success', 'Photo removed.');
        redirect('admin/manage_gallery.php');
    }
}

$events = $pdo->query("SELECT event_id, title FROM events ORDER BY event_date DESC")->fetchAll();
$photos = $pdo->query(
    "SELECT g.gallery_id, g.title, g.image_path, g.status, g.uploaded_at, e.title AS event_title
     FROM gallery g JOIN events e ON g.event_id = e.event_id
     ORDER BY g.uploaded_at DESC"
)->fetchAll();

$pageTitle = 'Manage Gallery';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Manage Gallery</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">Upload Photo</h6>
        <form method="POST" enctype="multipart/form-data" class="row g-2 align-items-end">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="form_action" value="upload">
          <div class="col-md-4">
            <label class="form-label small">Event</label>
            <select name="event_id" class="form-select" required>
              <option value="">Select event...</option>
              <?php foreach ($events as $ev): ?>
                <option value="<?= $ev['event_id'] ?>"><?= sanitize($ev['title']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label small">Photo Title</label>
            <input type="text" name="title" class="form-control" placeholder="e.g. Opening Ceremony" required>
          </div>
          <div class="col-md-3">
            <label class="form-label small">Image File</label>
            <input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.png,.webp" required>
          </div>
          <div class="col-md-1">
            <button type="submit" class="btn btn-primary w-100">Upload</button>
          </div>
        </form>
      </div>

      <?php if (empty($photos)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">No gallery photos uploaded yet.</p>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($photos as $photo): ?>
            <div class="col-md-4 col-6">
              <div class="ex-card p-2">
                <img src="<?= APP_URL . '/' . sanitize($photo['image_path']) ?>" class="w-100 rounded mb-2" loading="lazy" style="aspect-ratio:4/3;object-fit:cover;" alt="<?= sanitize($photo['title']) ?>">
                <p class="fw-semibold small mb-0"><?= sanitize($photo['title']) ?></p>
                <p class="text-secondary small mb-2"><?= sanitize($photo['event_title']) ?></p>
                <div class="d-flex gap-2">
                  <form method="POST" class="flex-fill">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="form_action" value="toggle">
                    <input type="hidden" name="gallery_id" value="<?= $photo['gallery_id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-secondary w-100">
                      <?= $photo['status'] === 'active' ? 'Hide' : 'Unhide' ?>
                    </button>
                  </form>
                  <form method="POST" class="flex-fill" onsubmit="return confirm('Delete this photo permanently?');">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="form_action" value="delete">
                    <input type="hidden" name="gallery_id" value="<?= $photo['gallery_id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger w-100">Delete</button>
                  </form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
