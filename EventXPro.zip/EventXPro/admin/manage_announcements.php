<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'create' && empty($errors)) {
        $title     = trim($_POST['title'] ?? '');
        $content   = trim($_POST['content'] ?? '');
        $audience  = $_POST['target_audience'] ?? 'all';
        $isPinned  = isset($_POST['is_pinned']) ? 1 : 0;
        $status    = $_POST['status'] ?? 'draft';

        if (strlen($title) < 3) {
            $errors[] = 'Title must be at least 3 characters.';
        }
        if (strlen($content) < 5) {
            $errors[] = 'Please write some announcement content.';
        }

        if (empty($errors)) {
            $insert = $pdo->prepare(
                'INSERT INTO announcements (title, content, target_audience, is_pinned, status, created_by)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $insert->execute([$title, $content, $audience, $isPinned, $status, $_SESSION['user_id']]);

            $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
            $logStmt->execute([$_SESSION['user_id'], 'announcement_created', $title, $_SERVER['REMOTE_ADDR'] ?? null]);

            set_flash('success', 'Announcement saved.');
            redirect('admin/manage_announcements.php');
        }
    } elseif ($formAction === 'toggle_status' && empty($errors)) {
        $id = (int) $_POST['announcement_id'];
        $pdo->prepare("UPDATE announcements SET status = IF(status = 'published', 'archived', 'published') WHERE announcement_id = ?")
            ->execute([$id]);
        redirect('admin/manage_announcements.php');
    } elseif ($formAction === 'delete' && empty($errors)) {
        $id = (int) $_POST['announcement_id'];
        $pdo->prepare('DELETE FROM announcements WHERE announcement_id = ?')->execute([$id]);
        set_flash('success', 'Announcement deleted.');
        redirect('admin/manage_announcements.php');
    }
}

$announcements = $pdo->query(
    "SELECT a.*, u.full_name AS author FROM announcements a
     JOIN users u ON a.created_by = u.user_id
     ORDER BY a.is_pinned DESC, a.created_at DESC"
)->fetchAll();

$pageTitle = 'Manage Announcements';
include __DIR__ . '/../includes/header.php';

$statusBadge = ['draft' => 'text-bg-secondary', 'published' => 'text-bg-success', 'archived' => 'text-bg-dark'];
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Manage Announcements</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">New Announcement</h6>
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="form_action" value="create">

          <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control" rows="3" required></textarea>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-4">
              <label class="form-label small">Audience</label>
              <select name="target_audience" class="form-select">
                <option value="all">Everyone</option>
                <option value="student">Students</option>
                <option value="faculty">Faculty</option>
                <option value="organizer">Organizers</option>
                <option value="volunteer">Volunteers</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small">Status</label>
              <select name="status" class="form-select">
                <option value="published">Publish Now</option>
                <option value="draft">Save as Draft</option>
              </select>
            </div>
            <div class="col-md-4 d-flex align-items-end">
              <div class="form-check">
                <input type="checkbox" name="is_pinned" value="1" class="form-check-input" id="isPinned">
                <label class="form-check-label" for="isPinned">Pin to top</label>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-sm">Save Announcement</button>
        </form>
      </div>

      <?php if (empty($announcements)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">No announcements yet.</p>
        </div>
      <?php else: ?>
        <?php foreach ($announcements as $a): ?>
          <div class="ex-card mb-3">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div>
                <?php if ($a['is_pinned']): ?><i class="fa-solid fa-thumbtack text-primary me-1"></i><?php endif; ?>
                <span class="fw-semibold"><?= sanitize($a['title']) ?></span>
                <span class="badge <?= $statusBadge[$a['status']] ?> text-capitalize ms-2"><?= sanitize($a['status']) ?></span>
                <span class="badge text-bg-light text-dark text-capitalize ms-1"><?= sanitize($a['target_audience']) ?></span>
              </div>
              <div class="d-flex gap-2">
                <form method="POST">
                  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                  <input type="hidden" name="form_action" value="toggle_status">
                  <input type="hidden" name="announcement_id" value="<?= $a['announcement_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-secondary">
                    <?= $a['status'] === 'published' ? 'Archive' : 'Publish' ?>
                  </button>
                </form>
                <form method="POST" onsubmit="return confirm('Delete this announcement?');">
                  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                  <input type="hidden" name="form_action" value="delete">
                  <input type="hidden" name="announcement_id" value="<?= $a['announcement_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                </form>
              </div>
            </div>
            <p class="text-secondary small mb-1"><?= nl2br(sanitize($a['content'])) ?></p>
            <p class="text-secondary small mb-0">By <?= sanitize($a['author']) ?> · <?= date('d M Y', strtotime($a['created_at'])) ?></p>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
