<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$actionFilter = trim($_GET['action'] ?? '');

$sql = "SELECT a.log_id, a.action, a.description, a.ip_address, a.created_at, u.full_name
        FROM activity_logs a LEFT JOIN users u ON a.user_id = u.user_id WHERE 1=1";
$params = [];
if ($actionFilter !== '') {
    $sql .= " AND a.action LIKE ?";
    $params[] = "%$actionFilter%";
}
$sql .= " ORDER BY a.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$pageTitle = 'Activity Logs';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Activity Logs</h4>

      <form method="GET" class="mb-4">
        <input type="text" name="action" class="form-control" placeholder="Filter by action (e.g. login, event_created)..." value="<?= sanitize($actionFilter) ?>">
      </form>

      <?php if (empty($logs)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No activity recorded yet.</p></div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">User</th>
                  <th>Action</th>
                  <th>Description</th>
                  <th>IP</th>
                  <th class="pe-4">When</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($logs as $log): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($log['full_name'] ?? 'System') ?></td>
                    <td><span class="badge text-bg-light text-dark border"><?= sanitize($log['action']) ?></span></td>
                    <td><?= sanitize($log['description'] ?? '') ?></td>
                    <td class="text-secondary small"><?= sanitize($log['ip_address'] ?? '') ?></td>
                    <td class="pe-4 text-secondary small"><?= date('d M Y, H:i', strtotime($log['created_at'])) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
        <p class="text-secondary small mt-2">Showing latest 100 records.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
