<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

/**
 * Generates a full structure + data SQL dump using pure PDO — no
 * shell_exec/mysqldump dependency, so it works even on XAMPP setups
 * where shell_exec() is disabled.
 */
if (isset($_GET['download'])) {
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

    $filename = 'eventx_pro_backup_' . date('Y-m-d_His') . '.sql';
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    echo "-- EventX Pro Database Backup\n-- Generated: " . date('Y-m-d H:i:s') . "\n";
    echo "SET FOREIGN_KEY_CHECKS=0;\n\n";

    foreach ($tables as $table) {
        $createRow = $pdo->query("SHOW CREATE TABLE `$table`")->fetch();
        echo "-- --------------------------------------------------------\n";
        echo "-- Table: $table\n";
        echo "-- --------------------------------------------------------\n";
        echo "DROP TABLE IF EXISTS `$table`;\n";
        echo $createRow['Create Table'] . ";\n\n";

        $rowCount = (int) $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
        if ($rowCount === 0) {
            continue;
        }

        $stmt = $pdo->query("SELECT * FROM `$table`");
        $columns = null;
        $batch = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if ($columns === null) {
                $columns = array_keys($row);
            }
            $values = array_map(function ($v) use ($pdo) {
                return $v === null ? 'NULL' : $pdo->quote((string) $v);
            }, $row);
            $batch[] = '(' . implode(', ', $values) . ')';

            // Flush every 200 rows to keep memory bounded on large tables.
            if (count($batch) >= 200) {
                echo "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES\n"
                    . implode(",\n", $batch) . ";\n";
                $batch = [];
            }
        }
        if (!empty($batch)) {
            echo "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES\n"
                . implode(",\n", $batch) . ";\n";
        }
        echo "\n";
    }

    echo "SET FOREIGN_KEY_CHECKS=1;\n";

    $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
    $logStmt->execute([$_SESSION['user_id'], 'db_backup', $filename, $_SERVER['REMOTE_ADDR'] ?? null]);
    exit;
}

$tableStats = $pdo->query(
    "SELECT table_name, table_rows
     FROM information_schema.tables
     WHERE table_schema = DATABASE()
     ORDER BY table_name"
)->fetchAll();

$pageTitle = 'Database Backup';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-2">Database Backup</h4>
      <p class="text-secondary small mb-4">
        Generates a complete structure + data <code>.sql</code> dump using
        PHP/PDO directly — no <code>mysqldump</code> shell access required,
        so it works even where <code>shell_exec()</code> is disabled.
        Import the file via phpMyAdmin or <code>mysql &lt; file.sql</code>
        to restore.
      </p>

      <div class="ex-card mb-4">
        <a href="<?= APP_URL ?>/admin/backup.php?download=1" class="btn btn-primary">
          <i class="fa-solid fa-download me-1"></i>Download Full Backup Now
        </a>
      </div>

      <div class="ex-card p-0">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead><tr><th class="ps-4">Table</th><th class="pe-4">Approx. Rows</th></tr></thead>
            <tbody>
              <?php foreach ($tableStats as $t): ?>
                <tr>
                  <td class="ps-4"><code><?= sanitize($t['table_name']) ?></code></td>
                  <td class="pe-4"><?= (int) $t['table_rows'] ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
