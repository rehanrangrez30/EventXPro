<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['user_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('admin/manage_users.php');
    }

    $targetId = (int) $_POST['user_id'];
    if ($targetId === (int) $_SESSION['user_id']) {
        set_flash('danger', 'You cannot change the status of your own account.');
        redirect('admin/manage_users.php');
    }

    $action = $_POST['action'];
    $statusMap = ['activate' => 'active', 'deactivate' => 'inactive', 'ban' => 'banned'];

    if (isset($statusMap[$action])) {
        $upd = $pdo->prepare('UPDATE users SET status = ? WHERE user_id = ?');
        $upd->execute([$statusMap[$action], $targetId]);

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], 'user_' . $action, 'User #' . $targetId . ' set to ' . $statusMap[$action], $_SERVER['REMOTE_ADDR'] ?? null]);

        set_flash('success', 'User status updated to ' . $statusMap[$action] . '.');
    }
    redirect('admin/manage_users.php');
}

$search = trim($_GET['search'] ?? '');
$roleFilter = trim($_GET['role'] ?? '');

$sql = "SELECT u.user_id, u.full_name, u.email, u.phone, u.department, u.status, u.created_at, r.role_name
        FROM users u JOIN roles r ON u.role_id = r.role_id WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($roleFilter !== '') {
    $sql .= " AND r.role_name = ?";
    $params[] = $roleFilter;
}
$sql .= " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$statusBadge = ['active' => 'text-bg-success', 'inactive' => 'text-bg-secondary', 'banned' => 'text-bg-danger'];

$pageTitle = 'Manage Users';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">Manage Users</h4>
        <a href="<?= APP_URL ?>/admin/export.php?type=users" class="btn btn-outline-secondary btn-sm">
          <i class="fa-solid fa-file-csv me-1"></i>Export CSV
        </a>
      </div>

      <form method="GET" class="row g-2 mb-4">
        <div class="col-md-7">
          <input type="text" name="search" class="form-control" placeholder="Search by name or email..." value="<?= sanitize($search) ?>">
        </div>
        <div class="col-md-3">
          <select name="role" class="form-select">
            <option value="">All Roles</option>
            <?php foreach (['admin', 'organizer', 'faculty', 'student', 'volunteer'] as $r): ?>
              <option value="<?= $r ?>" <?= $roleFilter === $r ? 'selected' : '' ?>><?= ucfirst($r) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
      </form>

      <div class="ex-card p-0">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th class="ps-4">Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th class="text-end pe-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($users as $u): ?>
                <tr>
                  <td class="ps-4"><?= sanitize($u['full_name']) ?></td>
                  <td><?= sanitize($u['email']) ?></td>
                  <td class="text-capitalize"><?= sanitize($u['role_name']) ?></td>
                  <td><span class="badge <?= $statusBadge[$u['status']] ?? 'text-bg-secondary' ?> text-capitalize"><?= sanitize($u['status']) ?></span></td>
                  <td class="text-end pe-4">
                    <?php if ((int) $u['user_id'] !== (int) $_SESSION['user_id']): ?>
                      <form method="POST" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="user_id" value="<?= $u['user_id'] ?>">
                        <?php if ($u['status'] !== 'active'): ?>
                          <button type="submit" name="action" value="activate" class="btn btn-sm btn-outline-success">Activate</button>
                        <?php else: ?>
                          <button type="submit" name="action" value="deactivate" class="btn btn-sm btn-outline-secondary">Deactivate</button>
                        <?php endif; ?>
                        <?php if ($u['status'] !== 'banned'): ?>
                          <button type="submit" name="action" value="ban" class="btn btn-sm btn-outline-danger" onclick="return confirm('Ban this user?');">Ban</button>
                        <?php endif; ?>
                      </form>
                    <?php else: ?>
                      <span class="text-secondary small">You</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
