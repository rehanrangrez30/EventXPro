<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$type = $_GET['type'] ?? '';
$allowed = ['users', 'events', 'registrations', 'attendance'];

if (!in_array($type, $allowed, true)) {
    set_flash('danger', 'Invalid export type requested.');
    redirect('admin/dashboard.php');
}

$queries = [
    'users' => [
        'sql' => "SELECT u.user_id, u.full_name, u.email, u.phone, r.role_name, u.department, u.status, u.created_at
                   FROM users u JOIN roles r ON u.role_id = r.role_id ORDER BY u.user_id",
        'headers' => ['User ID', 'Full Name', 'Email', 'Phone', 'Role', 'Department', 'Status', 'Registered On'],
    ],
    'events' => [
        'sql' => "SELECT e.event_id, e.title, c.category_name, e.event_date, e.venue, e.status, u.full_name AS organizer
                   FROM events e LEFT JOIN event_categories c ON e.category_id = c.category_id
                   JOIN users u ON e.organizer_id = u.user_id ORDER BY e.event_date DESC",
        'headers' => ['Event ID', 'Title', 'Category', 'Date', 'Venue', 'Status', 'Organizer'],
    ],
    'registrations' => [
        'sql' => "SELECT r.registration_id, e.title AS event_title, u.full_name AS student, r.status, r.registered_at
                   FROM registrations r JOIN events e ON r.event_id = e.event_id
                   JOIN users u ON r.student_id = u.user_id ORDER BY r.registered_at DESC",
        'headers' => ['Registration ID', 'Event', 'Student', 'Status', 'Registered At'],
    ],
    'attendance' => [
        'sql' => "SELECT a.attendance_id, e.title AS event_title, u.full_name AS student, a.attendance_status, a.created_at
                   FROM attendance a JOIN events e ON a.event_id = e.event_id
                   JOIN users u ON a.student_id = u.user_id ORDER BY a.created_at DESC",
        'headers' => ['Attendance ID', 'Event', 'Student', 'Status', 'Marked At'],
    ],
];

$config = $queries[$type];
$rows = $pdo->query($config['sql'])->fetchAll();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="eventx_' . $type . '_' . date('Y-m-d') . '.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, $config['headers']);
foreach ($rows as $row) {
    fputcsv($out, $row);
}
fclose($out);

$logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
$logStmt->execute([$_SESSION['user_id'], 'export', 'Exported ' . $type . ' as CSV', $_SERVER['REMOTE_ADDR'] ?? null]);
exit;
