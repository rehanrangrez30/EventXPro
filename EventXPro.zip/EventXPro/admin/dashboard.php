<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$userCounts = $pdo->query(
    "SELECT r.role_name, COUNT(u.user_id) AS total
     FROM roles r LEFT JOIN users u ON u.role_id = r.role_id
     GROUP BY r.role_name"
)->fetchAll();

$totalUsers = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeUsers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();

$totalEvents = (int) $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$publishedEvents = (int) $pdo->query("SELECT COUNT(*) FROM events WHERE status = 'published'")->fetchColumn();
$totalRegistrations = (int) $pdo->query("SELECT COUNT(*) FROM registrations WHERE status = 'registered'")->fetchColumn();

$recentActivity = $pdo->query(
    "SELECT a.action, a.description, a.created_at, u.full_name
     FROM activity_logs a LEFT JOIN users u ON a.user_id = u.user_id
     ORDER BY a.created_at DESC LIMIT 8"
)->fetchAll();

// Chart data: registrations per day for the last 7 days.
$trendRaw = $pdo->query(
    "SELECT DATE(registered_at) AS reg_date, COUNT(*) AS total
     FROM registrations
     WHERE registered_at >= NOW() - INTERVAL 6 DAY
     GROUP BY DATE(registered_at)"
)->fetchAll(PDO::FETCH_KEY_PAIR);

$trendLabels = [];
$trendValues = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i day"));
    $trendLabels[] = date('d M', strtotime($day));
    $trendValues[] = (int) ($trendRaw[$day] ?? 0);
}

// Chart data: events grouped by category.
$categoryChart = $pdo->query(
    "SELECT c.category_name, COUNT(e.event_id) AS total
     FROM event_categories c LEFT JOIN events e ON e.category_id = c.category_id
     GROUP BY c.category_name
     HAVING total > 0"
)->fetchAll();

$pageTitle = 'Admin Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Welcome, <?= sanitize($_SESSION['full_name']) ?> 👋</h4>

      <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $totalUsers ?></div>
            <div class="text-secondary small">Total Users</div>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $activeUsers ?></div>
            <div class="text-secondary small">Active Users</div>
          </div>
        </div>
        <?php foreach ($userCounts as $rc): if (in_array($rc['role_name'], ['organizer', 'student'], true)): ?>
        <div class="col-md-3 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= (int) $rc['total'] ?></div>
            <div class="text-secondary small text-capitalize"><?= sanitize($rc['role_name']) ?>s</div>
          </div>
        </div>
        <?php endif; endforeach; ?>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $totalEvents ?></div>
            <div class="text-secondary small">Total Events</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $publishedEvents ?></div>
            <div class="text-secondary small">Published Events</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $totalRegistrations ?></div>
            <div class="text-secondary small">Total Registrations</div>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">Users by Role</h6>
        <div class="row g-3">
          <?php foreach ($userCounts as $rc): ?>
            <div class="col-md-4 col-6 text-center">
              <div class="fw-bold fs-5"><?= (int) $rc['total'] ?></div>
              <div class="text-secondary small text-capitalize"><?= sanitize($rc['role_name']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-7">
          <div class="ex-card h-100">
            <h6 class="fw-semibold mb-3">Registrations — Last 7 Days</h6>
            <canvas id="registrationTrendChart" height="160"></canvas>
          </div>
        </div>
        <div class="col-md-5">
          <div class="ex-card h-100">
            <h6 class="fw-semibold mb-3">Events by Category</h6>
            <?php if (empty($categoryChart)): ?>
              <p class="text-secondary small mb-0">No events with a category yet.</p>
            <?php else: ?>
              <canvas id="categoryChart" height="160"></canvas>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">Quick Actions</h6>
        <a href="<?= APP_URL ?>/admin/manage_users.php" class="btn btn-sm btn-outline-primary">Manage Users</a>
        <a href="<?= APP_URL ?>/admin/manage_events.php" class="btn btn-sm btn-outline-primary">Manage Events</a>
        <a href="<?= APP_URL ?>/admin/manage_categories.php" class="btn btn-sm btn-outline-primary">Categories</a>
        <a href="<?= APP_URL ?>/admin/activity_logs.php" class="btn btn-sm btn-outline-primary">Activity Logs</a>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">Reports (CSV Export)</h6>
        <a href="<?= APP_URL ?>/admin/export.php?type=users" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-file-csv me-1"></i>Users</a>
        <a href="<?= APP_URL ?>/admin/export.php?type=events" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-file-csv me-1"></i>Events</a>
        <a href="<?= APP_URL ?>/admin/export.php?type=registrations" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-file-csv me-1"></i>Registrations</a>
        <a href="<?= APP_URL ?>/admin/export.php?type=attendance" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-file-csv me-1"></i>Attendance</a>
      </div>

      <div class="ex-card">
        <h6 class="fw-semibold mb-3">Recent Activity</h6>
        <?php if (empty($recentActivity)): ?>
          <p class="text-secondary small mb-0">No activity recorded yet.</p>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($recentActivity as $log): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span>
                  <strong><?= sanitize($log['full_name'] ?? 'System') ?></strong>
                  — <?= sanitize($log['description'] ?? $log['action']) ?>
                </span>
                <span class="text-secondary small"><?= date('d M, H:i', strtotime($log['created_at'])) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('registrationTrendChart'), {
  type: 'line',
  data: {
    labels: <?= json_encode($trendLabels) ?>,
    datasets: [{
      label: 'Registrations',
      data: <?= json_encode($trendValues) ?>,
      borderColor: '#2563eb',
      backgroundColor: 'rgba(37,99,235,0.1)',
      tension: 0.3,
      fill: true
    }]
  },
  options: {
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
  }
});

<?php if (!empty($categoryChart)): ?>
new Chart(document.getElementById('categoryChart'), {
  type: 'doughnut',
  data: {
    labels: <?= json_encode(array_column($categoryChart, 'category_name')) ?>,
    datasets: [{
      data: <?= json_encode(array_map('intval', array_column($categoryChart, 'total'))) ?>,
      backgroundColor: ['#2563eb', '#7c3aed', '#16a34a', '#d97706', '#dc2626', '#0891b2']
    }]
  },
  options: { plugins: { legend: { position: 'bottom' } } }
});
<?php endif; ?>
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
