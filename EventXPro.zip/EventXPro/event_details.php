<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$eventId = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    "SELECT e.*, c.category_name, c.icon_class, u.full_name AS organizer_name
     FROM events e
     LEFT JOIN event_categories c ON e.category_id = c.category_id
     LEFT JOIN users u ON e.organizer_id = u.user_id
     WHERE e.event_id = ? AND e.status = 'published'"
);
$stmt->execute([$eventId]);
$event = $stmt->fetch();

if (!$event) {
    redirect('errors/404.php');
}

$seatsStmt = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ? AND status = 'registered'");
$seatsStmt->execute([$eventId]);
$seatsTaken = (int) $seatsStmt->fetchColumn();

$seatsLeft = $event['max_participants'] > 0 ? max(0, $event['max_participants'] - $seatsTaken) : null;
$deadlinePassed = strtotime($event['registration_deadline']) < time();
$isFull = $seatsLeft !== null && $seatsLeft <= 0;

$alreadyRegistered = false;
if (is_logged_in() && $_SESSION['role_name'] === 'student') {
    $check = $pdo->prepare("SELECT registration_id FROM registrations WHERE event_id = ? AND student_id = ? AND status = 'registered'");
    $check->execute([$eventId, $_SESSION['user_id']]);
    $alreadyRegistered = (bool) $check->fetch();
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    if (!is_logged_in()) {
        redirect('login.php');
    }
    if ($_SESSION['role_name'] !== 'student') {
        $errors[] = 'Only students can register for events.';
    }
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }
    if ($deadlinePassed) {
        $errors[] = 'The registration deadline for this event has passed.';
    }
    if ($isFull) {
        $errors[] = 'This event has reached its maximum number of participants.';
    }
    if ($alreadyRegistered) {
        $errors[] = 'You are already registered for this event.';
    }

    if (empty($errors)) {
        $insert = $pdo->prepare("INSERT INTO registrations (event_id, student_id) VALUES (?, ?)");
        $insert->execute([$eventId, $_SESSION['user_id']]);

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], 'event_registration', 'Registered for: ' . $event['title'], $_SERVER['REMOTE_ADDR'] ?? null]);

        notify_user($pdo, $_SESSION['user_id'], 'Registration Confirmed', 'You are registered for "' . $event['title'] . '" on ' . date('d M Y', strtotime($event['event_date'])) . '.', 'registration', $eventId, 'student/my_registrations.php');

        // Best-effort confirmation email — never blocks registration if
        // SMTP isn't configured or the send fails (see includes/mailer.php).
        require_once __DIR__ . '/includes/mailer.php';
        require_once __DIR__ . '/includes/email_templates.php';
        send_mail(
            $_SESSION['email'],
            $_SESSION['full_name'],
            'Registration Confirmed: ' . $event['title'],
            eventx_registration_email_body(
                $_SESSION['full_name'],
                $event['title'],
                date('d M Y', strtotime($event['event_date'])),
                $event['venue'],
                APP_URL . '/event_details.php?id=' . $eventId
            )
        );

        set_flash('success', 'You have successfully registered for "' . $event['title'] . '".');
        redirect('event_details.php?id=' . $eventId);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_registration'])) {
    if (is_logged_in() && verify_csrf($_POST['csrf_token'] ?? '')) {
        $cancel = $pdo->prepare("UPDATE registrations SET status = 'cancelled' WHERE event_id = ? AND student_id = ?");
        $cancel->execute([$eventId, $_SESSION['user_id']]);
        set_flash('success', 'Your registration has been cancelled.');
        redirect('event_details.php?id=' . $eventId);
    }
}

$pageTitle = $event['title'];

// --- AI-style recommendation: rule-based "similar events" ---
// Same category, upcoming, published, excluding this event, soonest first.
// No ML/external API — pure SQL scoring, keeps the project dependency-free.
$similarEvents = [];
if (!empty($event['category_id'])) {
    $simStmt = $pdo->prepare(
        "SELECT e.event_id, e.title, e.event_date, e.venue, c.icon_class
         FROM events e
         LEFT JOIN event_categories c ON e.category_id = c.category_id
         WHERE e.status = 'published' AND e.event_date >= CURDATE()
           AND e.category_id = ? AND e.event_id != ?
         ORDER BY e.event_date ASC LIMIT 3"
    );
    $simStmt->execute([$event['category_id'], $eventId]);
    $similarEvents = $simStmt->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<section class="container py-5">
  <div class="row g-4">
    <div class="col-lg-8" data-aos="fade-up">
      <div class="ex-card">
        <span class="badge text-bg-primary mb-2"><?= sanitize($event['category_name'] ?? 'General') ?></span>
        <h2 class="fw-bold mb-3"><?= sanitize($event['title']) ?></h2>
        <p class="text-secondary"><?= nl2br(sanitize($event['description'])) ?></p>

        <hr>
        <div class="row g-3">
          <div class="col-sm-6"><i class="fa-regular fa-calendar text-primary me-2"></i><?= date('d M Y', strtotime($event['event_date'])) ?></div>
          <div class="col-sm-6"><i class="fa-regular fa-clock text-primary me-2"></i><?= date('h:i A', strtotime($event['start_time'])) ?> – <?= date('h:i A', strtotime($event['end_time'])) ?></div>
          <div class="col-sm-6"><i class="fa-solid fa-location-dot text-primary me-2"></i><?= sanitize($event['venue']) ?></div>
          <div class="col-sm-6"><i class="fa-solid fa-user-tie text-primary me-2"></i>Organized by <?= sanitize($event['organizer_name'] ?? 'N/A') ?></div>
        </div>
      </div>
    </div>

    <div class="col-lg-4" data-aos="fade-up">
      <div class="ex-card">
        <h6 class="fw-semibold mb-3">Registration</h6>

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger small">
            <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
          </div>
        <?php endif; ?>

        <p class="small text-secondary mb-1">
          Seats: <?= $seatsLeft === null ? 'Unlimited' : $seatsLeft . ' left of ' . (int) $event['max_participants'] ?>
        </p>
        <p class="small text-secondary mb-3">
          Deadline: <?= date('d M Y, h:i A', strtotime($event['registration_deadline'])) ?>
        </p>

        <?php if (!is_logged_in()): ?>
          <a href="<?= APP_URL ?>/login.php" class="btn btn-primary w-100">Log In to Register</a>
        <?php elseif ($_SESSION['role_name'] !== 'student'): ?>
          <p class="text-secondary small mb-0">Only student accounts can register for events.</p>
        <?php elseif ($alreadyRegistered): ?>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <button type="submit" name="cancel_registration" value="1" class="btn btn-outline-danger w-100">Cancel Registration</button>
          </form>
        <?php elseif ($deadlinePassed): ?>
          <button class="btn btn-secondary w-100" disabled>Registration Closed</button>
        <?php elseif ($isFull): ?>
          <button class="btn btn-secondary w-100" disabled>Event Full</button>
        <?php else: ?>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <button type="submit" name="register" value="1" class="btn btn-primary w-100">Register Now</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <?php if (!empty($similarEvents)): ?>
  <div class="mt-5" data-aos="fade-up">
    <h5 class="fw-bold mb-3">You Might Also Like</h5>
    <div class="row g-3">
      <?php foreach ($similarEvents as $sim): ?>
        <div class="col-md-4">
          <div class="ex-card h-100">
            <i class="fa-solid <?= sanitize($sim['icon_class'] ?: 'fa-calendar') ?> fa-2x text-primary mb-3"></i>
            <h6 class="fw-semibold"><?= sanitize($sim['title']) ?></h6>
            <p class="text-secondary small mb-3">
              <i class="fa-regular fa-calendar me-1"></i><?= date('d M Y', strtotime($sim['event_date'])) ?>
              &nbsp;·&nbsp;<i class="fa-solid fa-location-dot me-1"></i><?= sanitize($sim['venue']) ?>
            </p>
            <a href="<?= APP_URL ?>/event_details.php?id=<?= $sim['event_id'] ?>" class="btn btn-sm btn-outline-primary mt-auto">View Details</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
