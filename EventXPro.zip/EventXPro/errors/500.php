<?php
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}
http_response_code(500);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Something went wrong - <?= defined('APP_NAME') ? APP_NAME : 'EventX Pro' ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height:100vh;background:#f8fafc;">
  <div class="text-center p-4">
    <i class="fa-solid fa-triangle-exclamation fa-3x text-danger mb-3"></i>
    <h2 class="fw-bold mb-2">500 – Something Went Wrong</h2>
    <p class="text-secondary mb-4">
      An unexpected error occurred on our end. It has been logged and our
      team will look into it. Please try again in a moment.
    </p>
    <a href="<?= defined('APP_URL') ? APP_URL . '/index.php' : '/' ?>" class="btn btn-primary">Back to Home</a>
  </div>
</body>
</html>
