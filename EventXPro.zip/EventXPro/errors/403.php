<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
http_response_code(403);
$pageTitle = 'Access Denied';
include __DIR__ . '/../includes/header.php';
?>
<section class="container py-5 text-center">
  <div class="ex-card mx-auto" style="max-width:520px;">
    <i class="fa-solid fa-lock text-danger fa-3x mb-3"></i>
    <h2 class="fw-bold mb-2">403 – Access Denied</h2>
    <p class="text-secondary mb-4">
      You don't have permission to view this page. If you believe this is a
      mistake, please contact your administrator.
    </p>
    <a href="<?= APP_URL ?>/index.php" class="btn btn-primary">Back to Home</a>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
