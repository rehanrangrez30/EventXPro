<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$myActivity = $pdo->prepare(
    "SELECT action, description, created_at FROM activity_logs
     WHERE user_id = ? ORDER BY created_at DESC LIMIT 6"
);
$myActivity->execute([$_SESSION['user_id']]);
$logs = $myActivity->fetchAll();

$regCount = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE student_id = ? AND status = 'registered'");
$regCount->execute([$_SESSION['user_id']]);
$eventsRegistered = (int) $regCount->fetchColumn();

$upcoming = $pdo->prepare(
    "SELECT e.title, e.event_date, e.venue FROM registrations r
     JOIN events e ON r.event_id = e.event_id
     WHERE r.student_id = ? AND r.status = 'registered' AND e.event_date >= CURDATE()
     ORDER BY e.event_date ASC LIMIT 5"
);
$upcoming->execute([$_SESSION['user_id']]);
$upcomingEvents = $upcoming->fetchAll();

$certCount = $pdo->prepare("SELECT COUNT(*) FROM certificates WHERE student_id = ? AND certificate_status = 'generated'");
$certCount->execute([$_SESSION['user_id']]);
$certificatesEarned = (int) $certCount->fetchColumn();

$pendingFeedbackStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM registrations r
     JOIN events e ON r.event_id = e.event_id
     WHERE r.student_id = ? AND r.status = 'registered' AND e.event_date < CURDATE()
       AND NOT EXISTS (SELECT 1 FROM feedback f WHERE f.registration_id = r.registration_id)"
);
$pendingFeedbackStmt->execute([$_SESSION['user_id']]);
$pendingFeedback = (int) $pendingFeedbackStmt->fetchColumn();

// --- AI-style recommendation: rule-based, based on the student's own
// registration history (most-registered category), no ML/external API ---
$recommended = $pdo->prepare(
    "SELECT e.event_id, e.title, e.event_date, e.venue, c.icon_class
     FROM events e
     LEFT JOIN event_categories c ON e.category_id = c.category_id
     WHERE e.status = 'published' AND e.event_date >= CURDATE()
       AND e.category_id = (
           SELECT ev.category_id
           FROM registrations r2
           JOIN events ev ON r2.event_id = ev.event_id
           WHERE r2.student_id = ? AND ev.category_id IS NOT NULL
           GROUP BY ev.category_id
           ORDER BY COUNT(*) DESC LIMIT 1
       )
       AND e.event_id NOT IN (
           SELECT event_id FROM registrations WHERE student_id = ? AND status = 'registered'
       )
     ORDER BY e.event_date ASC LIMIT 3"
);
$recommended->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$recommendedEvents = $recommended->fetchAll();

$pageTitle = 'Student Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Welcome, <?= sanitize($_SESSION['full_name']) ?> 👋</h4>

      <div class="row g-3 mb-4">
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $eventsRegistered ?></div>
            <div class="text-secondary small">Events Registered</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $certificatesEarned ?></div>
            <div class="text-secondary small">Certificates Earned</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $pendingFeedback ?></div>
            <div class="text-secondary small">Pending Feedback</div>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3">My Upcoming Events</h6>
        <?php if (empty($upcomingEvents)): ?>
          <p class="text-secondary small mb-2">You have no upcoming registered events.</p>
          <a href="<?= APP_URL ?>/student/events.php" class="btn btn-sm btn-primary">Browse Events</a>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($upcomingEvents as $ue): ?>
              <li class="list-group-item d-flex justify-content-between px-0">
                <span><?= sanitize($ue['title']) ?> <span class="text-secondary small">— <?= sanitize($ue['venue']) ?></span></span>
                <span class="text-secondary small"><?= date('d M Y', strtotime($ue['event_date'])) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>

      <?php if (!empty($recommendedEvents)): ?>
      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-3"><i class="fa-solid fa-wand-magic-sparkles text-primary me-1"></i>Recommended for You</h6>
        <div class="row g-3">
          <?php foreach ($recommendedEvents as $rec): ?>
            <div class="col-md-4">
              <div class="border rounded-3 p-3 h-100">
                <h6 class="fw-semibold small mb-1"><?= sanitize($rec['title']) ?></h6>
                <p class="text-secondary small mb-2"><?= date('d M Y', strtotime($rec['event_date'])) ?> · <?= sanitize($rec['venue']) ?></p>
                <a href="<?= APP_URL ?>/event_details.php?id=<?= $rec['event_id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <div class="ex-card">
        <h6 class="fw-semibold mb-3">My Recent Activity</h6>
        <?php if (empty($logs)): ?>
          <p class="text-secondary small mb-0">No activity recorded yet.</p>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($logs as $log): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span><?= sanitize($log['description'] ?? $log['action']) ?></span>
                <span class="text-secondary small"><?= date('d M, H:i', strtotime($log['created_at'])) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
