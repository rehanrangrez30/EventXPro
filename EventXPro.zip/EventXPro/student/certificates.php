<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$stmt = $pdo->prepare(
    "SELECT c.certificate_number, c.verification_code, c.certificate_type, c.issue_date, c.pdf_path, e.title
     FROM certificates c JOIN events e ON c.event_id = e.event_id
     WHERE c.student_id = ? AND c.certificate_status = 'generated'
     ORDER BY c.issue_date DESC"
);
$stmt->execute([$_SESSION['user_id']]);
$certificates = $stmt->fetchAll();

$pageTitle = 'My Certificates';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">My Certificates</h4>

      <?php if (empty($certificates)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">
            No certificates yet. Certificates appear here once an organizer
            marks you present and generates one for a completed event.
          </p>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($certificates as $cert): ?>
            <div class="col-md-6">
              <div class="ex-card h-100 d-flex flex-column">
                <span class="badge text-bg-primary mb-2 text-capitalize"><?= sanitize($cert['certificate_type']) ?></span>
                <h6 class="fw-semibold"><?= sanitize($cert['title']) ?></h6>
                <p class="text-secondary small mb-1">Certificate No: <strong><?= sanitize($cert['certificate_number']) ?></strong></p>
                <p class="text-secondary small mb-1">Issued: <?= date('d M Y', strtotime($cert['issue_date'])) ?></p>
                <p class="text-secondary small mb-3">Verification Code: <code><?= sanitize($cert['verification_code']) ?></code></p>
                <div class="d-flex gap-2 mt-auto">
                  <?php if ($cert['pdf_path']): ?>
                    <a href="<?= APP_URL . '/' . sanitize($cert['pdf_path']) ?>" class="btn btn-sm btn-primary" download>
                      <i class="fa-solid fa-download me-1"></i>Download PDF
                    </a>
                  <?php endif; ?>
                  <a href="<?= APP_URL ?>/certificate_verify.php?code=<?= urlencode($cert['verification_code']) ?>" class="btn btn-sm btn-outline-secondary">Verify</a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
