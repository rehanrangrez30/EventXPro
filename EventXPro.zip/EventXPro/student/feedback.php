<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }

    $eventId = (int) ($_POST['event_id'] ?? 0);
    $rating = (int) ($_POST['overall_rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');

    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Please select a rating between 1 and 5.';
    }

    if (empty($errors)) {
        $eligible = $pdo->prepare(
            "SELECT r.registration_id FROM registrations r
             JOIN attendance a ON a.registration_id = r.registration_id AND a.attendance_status = 'present'
             JOIN events e ON r.event_id = e.event_id
             WHERE r.event_id = ? AND r.student_id = ? AND e.event_date < CURDATE()"
        );
        $eligible->execute([$eventId, $_SESSION['user_id']]);
        $regRow = $eligible->fetch();

        if (!$regRow) {
            $errors[] = 'You can only submit feedback for events you attended.';
        } else {
            try {
                $insert = $pdo->prepare(
                    'INSERT INTO feedback (registration_id, student_id, event_id, overall_rating, comment)
                     VALUES (?, ?, ?, ?, ?)'
                );
                $insert->execute([$regRow['registration_id'], $_SESSION['user_id'], $eventId, $rating, $comment ?: null]);
                set_flash('success', 'Thank you for your feedback!');
                redirect('student/feedback.php');
            } catch (PDOException $e) {
                $errors[] = 'You have already submitted feedback for this event.';
            }
        }
    }
}

// Events the student attended (present) but hasn't reviewed yet.
$pending = $pdo->prepare(
    "SELECT e.event_id, e.title, e.event_date FROM registrations r
     JOIN attendance a ON a.registration_id = r.registration_id AND a.attendance_status = 'present'
     JOIN events e ON r.event_id = e.event_id
     LEFT JOIN feedback f ON f.event_id = e.event_id AND f.student_id = r.student_id
     WHERE r.student_id = ? AND e.event_date < CURDATE() AND f.feedback_id IS NULL
     ORDER BY e.event_date DESC"
);
$pending->execute([$_SESSION['user_id']]);
$pendingEvents = $pending->fetchAll();

$submitted = $pdo->prepare(
    "SELECT f.overall_rating, f.comment, f.submitted_at, e.title
     FROM feedback f JOIN events e ON f.event_id = e.event_id
     WHERE f.student_id = ? ORDER BY f.submitted_at DESC"
);
$submitted->execute([$_SESSION['user_id']]);
$myFeedback = $submitted->fetchAll();

$pageTitle = 'Feedback';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Event Feedback</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <?php if (empty($pendingEvents)): ?>
        <div class="ex-card text-center py-4 mb-4">
          <p class="text-secondary mb-0">No events awaiting your feedback right now.</p>
        </div>
      <?php else: ?>
        <div class="ex-card mb-4">
          <h6 class="fw-semibold mb-3">Share Your Feedback</h6>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <div class="mb-3">
              <label class="form-label">Event</label>
              <select name="event_id" class="form-select" required>
                <?php foreach ($pendingEvents as $pe): ?>
                  <option value="<?= $pe['event_id'] ?>"><?= sanitize($pe['title']) ?> — <?= date('d M Y', strtotime($pe['event_date'])) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Overall Rating</label>
              <select name="overall_rating" class="form-select" required>
                <option value="">Select rating...</option>
                <?php for ($i = 5; $i >= 1; $i--): ?>
                  <option value="<?= $i ?>"><?= str_repeat('★', $i) . str_repeat('☆', 5 - $i) ?></option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Comments (optional)</label>
              <textarea name="comment" class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Feedback</button>
          </form>
        </div>
      <?php endif; ?>

      <?php if (!empty($myFeedback)): ?>
        <div class="ex-card">
          <h6 class="fw-semibold mb-3">Your Past Feedback</h6>
          <ul class="list-group list-group-flush">
            <?php foreach ($myFeedback as $fb): ?>
              <li class="list-group-item px-0">
                <div class="d-flex justify-content-between">
                  <strong><?= sanitize($fb['title']) ?></strong>
                  <span class="text-warning"><?= str_repeat('★', (int) $fb['overall_rating']) ?></span>
                </div>
                <?php if ($fb['comment']): ?><p class="text-secondary small mb-0 mt-1"><?= sanitize($fb['comment']) ?></p><?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
