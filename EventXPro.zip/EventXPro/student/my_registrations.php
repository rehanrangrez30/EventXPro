<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$stmt = $pdo->prepare(
    "SELECT r.registration_id, r.status AS reg_status, r.registered_at,
            e.event_id, e.title, e.event_date, e.venue
     FROM registrations r
     JOIN events e ON r.event_id = e.event_id
     WHERE r.student_id = ?
     ORDER BY e.event_date DESC"
);
$stmt->execute([$_SESSION['user_id']]);
$registrations = $stmt->fetchAll();

$pageTitle = 'My Registrations';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">My Registrations</h4>

      <?php if (empty($registrations)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-3">You haven't registered for any events yet.</p>
          <a href="<?= APP_URL ?>/student/events.php" class="btn btn-primary">Browse Events</a>
        </div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Event</th>
                  <th>Date</th>
                  <th>Venue</th>
                  <th>Status</th>
                  <th class="text-end pe-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($registrations as $r): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($r['title']) ?></td>
                    <td><?= date('d M Y', strtotime($r['event_date'])) ?></td>
                    <td><?= sanitize($r['venue']) ?></td>
                    <td>
                      <span class="badge <?= $r['reg_status'] === 'registered' ? 'text-bg-success' : 'text-bg-secondary' ?> text-capitalize">
                        <?= sanitize($r['reg_status']) ?>
                      </span>
                    </td>
                    <td class="text-end pe-4">
                      <a href="<?= APP_URL ?>/event_details.php?id=<?= $r['event_id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
