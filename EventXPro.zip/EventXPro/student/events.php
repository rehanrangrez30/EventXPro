<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('student');

$search = trim($_GET['search'] ?? '');

$sql = "SELECT e.event_id, e.title, e.event_date, e.venue, e.registration_deadline, c.category_name,
               (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id AND r.student_id = ? AND r.status = 'registered') AS is_registered
        FROM events e
        LEFT JOIN event_categories c ON e.category_id = c.category_id
        WHERE e.status = 'published' AND e.event_date >= CURDATE()";
$params = [$_SESSION['user_id']];

if ($search !== '') {
    $sql .= " AND e.title LIKE ?";
    $params[] = "%$search%";
}
$sql .= " ORDER BY e.event_date ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

$pageTitle = 'Browse Events';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Browse Events</h4>

      <form method="GET" class="mb-4">
        <input type="text" name="search" class="form-control" placeholder="Search events..." value="<?= sanitize($search) ?>">
      </form>

      <?php if (empty($events)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">No Upcoming Events Available.</p>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($events as $ev): ?>
            <div class="col-md-6">
              <div class="ex-card h-100">
                <span class="badge text-bg-primary mb-2"><?= sanitize($ev['category_name'] ?? 'General') ?></span>
                <h6 class="fw-semibold"><?= sanitize($ev['title']) ?></h6>
                <p class="text-secondary small mb-2">
                  <i class="fa-regular fa-calendar me-1"></i><?= date('d M Y', strtotime($ev['event_date'])) ?>
                  &nbsp;·&nbsp;<i class="fa-solid fa-location-dot me-1"></i><?= sanitize($ev['venue']) ?>
                </p>
                <?php if ($ev['is_registered']): ?>
                  <span class="badge text-bg-success mb-2">Registered</span>
                <?php endif; ?>
                <a href="<?= APP_URL ?>/event_details.php?id=<?= $ev['event_id'] ?>" class="btn btn-sm btn-outline-primary mt-auto">
                  <?= $ev['is_registered'] ? 'View / Manage' : 'View & Register' ?>
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
