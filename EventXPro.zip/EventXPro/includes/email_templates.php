<?php
/**
 * EventX Pro - Email Templates
 * Small, self-contained HTML templates (inline CSS only — email clients
 * don't reliably support external stylesheets).
 */

function eventx_email_wrapper(string $title, string $bodyHtml): string
{
    return '
    <div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;padding:24px;">
      <div style="background:linear-gradient(135deg,#2563eb,#7c3aed);border-radius:14px 14px 0 0;padding:24px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:22px;">' . APP_NAME . '</h1>
      </div>
      <div style="background:#ffffff;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 14px 14px;padding:28px;">
        <h2 style="color:#0f172a;font-size:18px;margin-top:0;">' . htmlspecialchars($title) . '</h2>
        ' . $bodyHtml . '
      </div>
      <p style="text-align:center;color:#94a3b8;font-size:12px;margin-top:16px;">
        ' . APP_NAME . ' &mdash; ' . APP_TAGLINE . '
      </p>
    </div>';
}

function eventx_registration_email_body(string $studentName, string $eventTitle, string $eventDate, string $venue, string $eventUrl): string
{
    $body = '
      <p style="color:#334155;line-height:1.6;">Hi ' . htmlspecialchars($studentName) . ',</p>
      <p style="color:#334155;line-height:1.6;">You\'re successfully registered for:</p>
      <div style="background:#f8fafc;border-radius:10px;padding:16px;margin:16px 0;">
        <p style="margin:0 0 6px;font-weight:bold;color:#0f172a;">' . htmlspecialchars($eventTitle) . '</p>
        <p style="margin:0;color:#64748b;font-size:14px;">📅 ' . htmlspecialchars($eventDate) . ' &nbsp;·&nbsp; 📍 ' . htmlspecialchars($venue) . '</p>
      </div>
      <p style="color:#334155;line-height:1.6;">See you there! You can view or cancel this registration anytime from your dashboard.</p>
      <p style="text-align:center;margin-top:20px;">
        <a href="' . $eventUrl . '" style="background:#2563eb;color:#fff;text-decoration:none;padding:10px 22px;border-radius:8px;display:inline-block;">View Event</a>
      </p>';
    return eventx_email_wrapper('Registration Confirmed ✅', $body);
}

function eventx_certificate_email_body(string $studentName, string $eventTitle, string $certNumber, string $verifyUrl): string
{
    $body = '
      <p style="color:#334155;line-height:1.6;">Hi ' . htmlspecialchars($studentName) . ',</p>
      <p style="color:#334155;line-height:1.6;">Your certificate for <strong>' . htmlspecialchars($eventTitle) . '</strong> is ready — attached to this email as a PDF.</p>
      <div style="background:#f8fafc;border-radius:10px;padding:16px;margin:16px 0;">
        <p style="margin:0;color:#64748b;font-size:14px;">Certificate No: <strong>' . htmlspecialchars($certNumber) . '</strong></p>
      </div>
      <p style="color:#334155;line-height:1.6;">Anyone can verify this certificate\'s authenticity using the link below.</p>
      <p style="text-align:center;margin-top:20px;">
        <a href="' . $verifyUrl . '" style="background:#2563eb;color:#fff;text-decoration:none;padding:10px 22px;border-radius:8px;display:inline-block;">Verify Certificate</a>
      </p>';
    return eventx_email_wrapper('Your Certificate is Ready 🎓', $body);
}
