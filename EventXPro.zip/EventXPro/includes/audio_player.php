<?php
/**
 * EventX Pro - Background Music Player
 * Uses ONLY the user-uploaded MP3 file (assets/audio/donu_donu.mp3).
 * Never replace or regenerate this file.
 */
?>
<div id="bgMusicPlayer" class="bg-music-player">
    <audio id="bgAudio" src="<?= APP_URL . '/' . BG_MUSIC_FILE ?>" loop preload="auto"></audio>

    <button id="bgMusicToggle" class="bg-music-icon" title="Music controls" aria-expanded="false" aria-controls="bgMusicControls">
        <i class="fa-solid fa-music"></i>
    </button>

    <div id="bgMusicControls" class="bg-music-controls">
        <button id="bgPlayPause" class="bg-music-btn" title="Play / Pause music">
            <i class="fa-solid fa-play"></i>
        </button>

        <input type="range" id="bgVolume" class="bg-music-volume" min="0" max="1" step="0.05" value="0.5" title="Volume">

        <button id="bgMute" class="bg-music-btn" title="Mute / Unmute">
            <i class="fa-solid fa-volume-high"></i>
        </button>
    </div>
</div>

<div id="bgMusicPrompt" class="bg-music-prompt d-none">
    <span>🎵 Tap to enable background music</span>
    <button id="bgMusicEnable" class="btn btn-sm btn-primary ms-2">Play Music</button>
</div>

<script src="<?= APP_URL ?>/assets/js/audio-player.js"></script>
