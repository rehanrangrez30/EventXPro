<?php
/**
 * EventX Pro - Certificate PDF Generator (template-based)
 *
 * Renders the certificate using the project's actual designed template
 * (assets/images/certificate/template.jpg) as a full-page background,
 * with dynamic per-student data (name, event, date, certificate number,
 * a genuinely scannable QR code) overlaid at positions measured against
 * that template.
 *
 * Still dependency-free in the "no Composer, no internet at runtime"
 * sense: the JPEG is embedded directly (DCTDecode — no re-encoding
 * needed) and the QR code is generated locally via the vendored
 * phpqrcode library (includes/vendor/phpqrcode), not a hosted API.
 */

require_once __DIR__ . '/vendor/phpqrcode/qrlib.php';

/** Loads a PNG (e.g. a freshly generated QR code), flattens to RGB, returns raw pixel bytes. */
function eventx_pdf_load_rgb_image(string $imagePath, int $maxDim = 400): ?array
{
    if (!extension_loaded('gd') || !is_readable($imagePath)) {
        return null;
    }
    $src = @imagecreatefrompng($imagePath);
    if (!$src) {
        return null;
    }

    $w = imagesx($src);
    $h = imagesy($src);
    $scale = min(1, $maxDim / max($w, $h));
    $nw = max(1, (int) round($w * $scale));
    $nh = max(1, (int) round($h * $scale));

    $flat = imagecreatetruecolor($nw, $nh);
    imagefill($flat, 0, 0, imagecolorallocate($flat, 255, 255, 255));
    imagecopyresampled($flat, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($src);

    $raw = '';
    for ($y = 0; $y < $nh; $y++) {
        for ($x = 0; $x < $nw; $x++) {
            $rgb = imagecolorat($flat, $x, $y);
            $raw .= chr(($rgb >> 16) & 0xFF) . chr(($rgb >> 8) & 0xFF) . chr($rgb & 0xFF);
        }
    }
    imagedestroy($flat);

    return ['width' => $nw, 'height' => $nh, 'raw' => $raw];
}

function eventx_generate_certificate_pdf(string $outputPath, array $data): bool
{
    $studentName = $data['student_name'] ?? '';
    $eventTitle  = $data['event_title'] ?? '';
    $eventDate   = $data['event_date'] ?? '';
    $certNumber  = $data['certificate_number'] ?? '';
    $verifyCode  = $data['verification_code'] ?? '';
    $issueDate   = $data['issue_date'] ?? date('d M Y');

    // Page matches the template artwork's own aspect ratio (1491x1055),
    // scaled to a standard landscape-A4-ish size in points.
    $pageWidth  = 842;
    $pageHeight = 595;
    $scaleX = $pageWidth / 1491;
    $scaleY = $pageHeight / 1055;
    $toX = static fn (float $imgX): float => $imgX * $scaleX;
    $toY = static fn (float $imgY): float => $pageHeight - $imgY * $scaleY;

    $esc = static fn (string $s): string => str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);

    // ---- Background template artwork ----
    $templatePath = __DIR__ . '/../assets/images/certificate/template.jpg';
    $templateJpeg = @file_get_contents($templatePath);
    $templateSize = @getimagesize($templatePath);
    if (!$templateJpeg || !$templateSize) {
        return false; // Template missing — nothing sensible to render.
    }

    // ---- Real, scannable QR code (generated locally, not via any API) ----
    $verifyUrl = APP_URL . '/certificate_verify.php?code=' . $verifyCode;
    $qrTmpPath = sys_get_temp_dir() . '/eventx_qr_' . bin2hex(random_bytes(6)) . '.png';
    QRcode::png($verifyUrl, $qrTmpPath, QR_ECLEVEL_M, 6, 1);
    $qrImage = eventx_pdf_load_rgb_image($qrTmpPath, 300);
    @unlink($qrTmpPath);

    // ---- Text overlay positions (measured in template pixel space, then
    // converted to PDF points) — each dynamic field first gets a cover
    // rectangle matching the template's paper color, so the artwork's own
    // placeholder text ("Your Name Here", etc.) is fully hidden underneath. ----
    $cream = "0.992 0.992 0.985 rg";

    $lines = [];

    // Student name (covers "Your Name Here" — tall box to fully hide cursive ascenders/descenders)
    [$x1, $y1] = [$toX(440), $toY(540)];
    [$x2, $y2] = [$toX(1055), $toY(642)];
    $lines[] = "q $cream $x1 $y2 " . ($x2 - $x1) . ' ' . ($y1 - $y2) . ' re f Q';
    $nameFontSize = strlen($studentName) > 22 ? 17 : 22;
    $nameWidthEst = strlen($studentName) * $nameFontSize * 0.42;
    $nameX = ($x1 + $x2) / 2 - $nameWidthEst / 2;
    $lines[] = "q 0.09 0.16 0.4 rg BT /F3 $nameFontSize Tf $nameX " . $toY(618) . " Td (" . $esc($studentName) . ") Tj ET Q";

    // Paragraph: "for participating in the event {X} organized by / EventX Pro on {date}."
    [$x1, $y1] = [$toX(450), $toY(660)];
    [$x2, $y2] = [$toX(1050), $toY(730)];
    $lines[] = "q $cream $x1 $y2 " . ($x2 - $x1) . ' ' . ($y1 - $y2) . ' re f Q';
    $centerXpt = ($x1 + $x2) / 2;
    $line1 = 'for participating in the event ' . $eventTitle . ' organized by';
    $line2 = APP_NAME . ' on ' . $eventDate . '.';
    $lines[] = "q 0.15 0.15 0.2 rg BT /F1 12 Tf " . ($centerXpt - strlen($line1) * 12 * 0.235) . ' ' . $toY(689) . ' Td (' . $esc($line1) . ') Tj ET Q';
    $lines[] = "q 0.09 0.16 0.4 rg BT /F2 12 Tf " . ($centerXpt - strlen($line2) * 12 * 0.24) . ' ' . $toY(716) . ' Td (' . $esc($line2) . ') Tj ET Q';

    // Certificate ID value (covers "EXPRO2025-0001")
    [$x1, $y1] = [$toX(150), $toY(941)];
    [$x2, $y2] = [$toX(330), $toY(960)];
    $lines[] = "q $cream $x1 $y2 " . ($x2 - $x1) . ' ' . ($y1 - $y2) . ' re f Q';
    $lines[] = "q 0.09 0.16 0.4 rg BT /F2 11 Tf $x1 " . $toY(954) . ' Td (' . $esc($certNumber) . ') Tj ET Q';

    // Date of issue value (covers "DD MMM YYYY")
    [$x1, $y1] = [$toX(150), $toY(997)];
    [$x2, $y2] = [$toX(310), $toY(1016)];
    $lines[] = "q $cream $x1 $y2 " . ($x2 - $x1) . ' ' . ($y1 - $y2) . ' re f Q';
    $lines[] = "q 0.15 0.15 0.2 rg BT /F1 11 Tf $x1 " . $toY(1010) . ' Td (' . $esc($issueDate) . ') Tj ET Q';

    // Real QR (covers the decorative placeholder QR graphic)
    if ($qrImage) {
        [$qx1, $qy1] = [$toX(10), $toY(893)];
        [$qx2, $qy2] = [$toX(125), $toY(1007)];
        $qrDraw = min($qx2 - $qx1, $qy1 - $qy2);
        $lines[] = "q 1 1 1 rg $qx1 $qy2 " . ($qx2 - $qx1) . ' ' . ($qy1 - $qy2) . ' re f Q';
        $lines[] = "q $qrDraw 0 0 $qrDraw $qx1 $qy2 cm /QR Do Q";
    }

    $content = implode("\n", $lines);

    // ---- Object assembly ----
    $objects = [];
    $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    $objects[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";

    $resources = "/Font << /F1 4 0 R /F2 5 0 R /F3 8 0 R >> /XObject << /Bg 7 0 R" . ($qrImage ? ' /QR 9 0 R' : '') . " >>";
    $objects[3] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pageWidth $pageHeight] "
                . "/Resources << $resources >> /Contents 6 0 R >>";
    $objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
    $objects[5] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";

    // Background image drawn first, then the text overlay content.
    $bgDraw = "q $pageWidth 0 0 $pageHeight 0 0 cm /Bg Do Q\n";
    $fullContent = $bgDraw . $content;
    $objects[6] = "<< /Length " . strlen($fullContent) . " >>\nstream\n$fullContent\nendstream";

    $objects[7] = "<< /Type /XObject /Subtype /Image /Width {$templateSize[0]} /Height {$templateSize[1]} "
                . "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " . strlen($templateJpeg) . " >>\n"
                . "stream\n$templateJpeg\nendstream";

    $objects[8] = "<< /Type /Font /Subtype /Type1 /BaseFont /Times-BoldItalic >>";

    if ($qrImage) {
        $compressed = gzcompress($qrImage['raw'], 6);
        $objects[9] = "<< /Type /XObject /Subtype /Image /Width {$qrImage['width']} /Height {$qrImage['height']} "
                    . "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length " . strlen($compressed) . " >>\n"
                    . "stream\n$compressed\nendstream";
    }

    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $num => $body) {
        $offsets[$num] = strlen($pdf);
        $pdf .= "$num 0 obj\n$body\nendobj\n";
    }

    $xrefStart = strlen($pdf);
    $count = count($objects) + 1;
    $pdf .= "xref\n0 $count\n0000000000 65535 f \n";
    for ($i = 1; $i <= count($objects); $i++) {
        $pdf .= str_pad((string) $offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }
    $pdf .= "trailer\n<< /Size $count /Root 1 0 R >>\nstartxref\n$xrefStart\n%%EOF";

    $dir = dirname($outputPath);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    return (bool) @file_put_contents($outputPath, $pdf);
}


