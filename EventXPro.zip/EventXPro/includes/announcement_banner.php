<?php
/**
 * EventX Pro - Announcement Banner
 * Shows the single most relevant published announcement (pinned first,
 * then newest) for the current visitor's audience on every page.
 */
$audienceFilter = ['all'];
if (is_logged_in() && !empty($_SESSION['role_name'])) {
    $audienceFilter[] = $_SESSION['role_name'];
}
$placeholders = implode(',', array_fill(0, count($audienceFilter), '?'));

$bannerStmt = $pdo->prepare(
    "SELECT title, content, is_pinned FROM announcements
     WHERE status = 'published' AND target_audience IN ($placeholders)
     ORDER BY is_pinned DESC, created_at DESC LIMIT 1"
);
$bannerStmt->execute($audienceFilter);
$banner = $bannerStmt->fetch();

if ($banner):
?>
<div class="container mt-3">
  <div class="alert <?= $banner['is_pinned'] ? 'alert-warning' : 'alert-info' ?> d-flex align-items-start gap-2 mb-0">
    <i class="fa-solid fa-bullhorn mt-1"></i>
    <div>
      <strong><?= sanitize($banner['title']) ?></strong>
      <span class="d-block small"><?= sanitize($banner['content']) ?></span>
    </div>
  </div>
</div>
<?php endif; ?>
