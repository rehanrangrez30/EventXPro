<?php
/**
 * EventX Pro - Shared Helper Functions
 */

/**
 * Sanitize user input for safe output.
 */
function sanitize(string $value): string
{
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect to a given internal path and stop execution.
 */
function redirect(string $path): void
{
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

/**
 * Check if a user is currently logged in.
 */
function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * Restrict access to a specific role. Redirects to login if not
 * authenticated, or to an access-denied page if the role doesn't match.
 */
function require_role(string $role): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }

    if (($_SESSION['role_name'] ?? '') !== $role) {
        redirect('errors/403.php');
    }
}

/**
 * Store a one-time flash message in the session.
 */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/**
 * Retrieve and clear the flash message, if any.
 */
function get_flash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Generate a CSRF token and store it in the session.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify a submitted CSRF token against the session token.
 */
function verify_csrf(string $token): bool
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Read a value from the settings table, with a fallback default.
 */
function get_setting(PDO $pdo, string $key, string $default = ''): string
{
    static $cache = [];
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    $stmt = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $cache[$key] = ($value !== false ? $value : $default);
}

/**
 * Create a notification for a user.
 */
function notify_user(PDO $pdo, int $userId, string $title, string $message, string $type = 'system', ?int $eventId = null, ?string $actionUrl = null): void
{
    $stmt = $pdo->prepare(
        'INSERT INTO notifications (user_id, event_id, title, message, notification_type, action_url)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$userId, $eventId, $title, $message, $type, $actionUrl]);
}
