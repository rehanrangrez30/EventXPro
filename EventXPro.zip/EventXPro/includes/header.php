<?php
/**
 * EventX Pro - Global Header
 * Included at the top of every page.
 */
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}
require_once __DIR__ . '/functions.php';
$flash = get_flash();

// Read the saved theme preference server-side so the correct theme is
// already in the very first byte of HTML — applying it only via JS after
// the page loads would flash light-mode first on every single page
// navigation (this is a multi-page app, not an SPA).
$initialTheme = (isset($_COOKIE['ex_theme']) && $_COOKIE['ex_theme'] === 'dark') ? 'dark' : 'light';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="<?= $initialTheme ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? sanitize($pageTitle) . ' - ' . APP_NAME : APP_NAME ?></title>

<!-- PWA -->
<link rel="manifest" href="<?= APP_URL ?>/manifest.json">
<meta name="theme-color" content="#2563eb">
<link rel="icon" type="image/png" sizes="32x32" href="<?= APP_URL ?>/assets/images/icons/favicon-32.png">
<link rel="apple-touch-icon" href="<?= APP_URL ?>/assets/images/icons/apple-touch-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="EventX Pro">
<meta name="description" content="<?= APP_TAGLINE ?>">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Tailwind CSS (utility classes only, no build step) -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<!-- AOS Animation -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.1/aos.css" rel="stylesheet">

<!-- Custom Styles -->
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/navbar.php'; ?>
<?php include __DIR__ . '/audio_player.php'; ?>

<?php if ($flash): ?>
<div class="container mt-3">
    <div class="alert alert-<?= sanitize($flash['type']) ?> alert-dismissible fade show" role="alert">
        <?= sanitize($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/announcement_banner.php'; ?>
<?php include __DIR__ . '/pwa_install_banner.php'; ?>
