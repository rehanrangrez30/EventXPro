<?php
/**
 * EventX Pro - Dashboard Sidebar
 * Included by every role dashboard. Only links to pages that exist
 * in the current phase are shown, so nothing points to a dead page.
 */
$role = $_SESSION['role_name'] ?? '';
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<div class="col-12 col-lg-3 mb-4">
  <div class="ex-card">
    <div class="text-center mb-3">
      <div class="rounded-circle bg-primary bg-opacity-10 d-inline-flex align-items-center justify-content-center mb-2" style="width:64px;height:64px;">
        <i class="fa-solid fa-user text-primary fa-lg"></i>
      </div>
      <h6 class="fw-semibold mb-0"><?= sanitize($_SESSION['full_name'] ?? '') ?></h6>
      <span class="badge text-bg-primary text-capitalize"><?= sanitize($role) ?></span>
    </div>
    <hr>
    <ul class="nav flex-column gap-1">
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'dashboard.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/<?= sanitize($role) ?>/dashboard.php">
          <i class="fa-solid fa-gauge me-2"></i>Dashboard
        </a>
      </li>
      <?php if ($role === 'student'): ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'events.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/student/events.php">
          <i class="fa-regular fa-calendar me-2"></i>Browse Events
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'my_registrations.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/student/my_registrations.php">
          <i class="fa-solid fa-clipboard-list me-2"></i>My Registrations
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'certificates.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/student/certificates.php">
          <i class="fa-solid fa-award me-2"></i>Certificates
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'feedback.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/student/feedback.php">
          <i class="fa-solid fa-star me-2"></i>Feedback
        </a>
      </li>
      <?php elseif ($role === 'organizer'): ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_events.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/organizer/manage_events.php">
          <i class="fa-solid fa-calendar-days me-2"></i>Manage Events
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'attendance.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/organizer/attendance.php">
          <i class="fa-solid fa-clipboard-check me-2"></i>Attendance
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'certificates.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/organizer/certificates.php">
          <i class="fa-solid fa-award me-2"></i>Certificates
        </a>
      </li>
      <?php elseif ($role === 'faculty'): ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'assigned_events.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/faculty/assigned_events.php">
          <i class="fa-solid fa-eye me-2"></i>My Assigned Events
        </a>
      </li>
      <?php elseif ($role === 'volunteer'): ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'assigned_events.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/volunteer/assigned_events.php">
          <i class="fa-solid fa-hands-helping me-2"></i>My Assigned Events
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'tasks.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/volunteer/tasks.php">
          <i class="fa-solid fa-list-check me-2"></i>My Tasks
        </a>
      </li>
      <?php elseif ($role === 'admin'): ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_users.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_users.php">
          <i class="fa-solid fa-users me-2"></i>Manage Users
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_events.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_events.php">
          <i class="fa-solid fa-calendar-days me-2"></i>Manage Events
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_categories.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_categories.php">
          <i class="fa-solid fa-tags me-2"></i>Categories
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'activity_logs.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/activity_logs.php">
          <i class="fa-solid fa-list-check me-2"></i>Activity Logs
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_gallery.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_gallery.php">
          <i class="fa-solid fa-images me-2"></i>Gallery
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_announcements.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_announcements.php">
          <i class="fa-solid fa-bullhorn me-2"></i>Announcements
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'manage_assignments.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/manage_assignments.php">
          <i class="fa-solid fa-user-tag me-2"></i>Assignments
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'export.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/export.php">
          <i class="fa-solid fa-file-export me-2"></i>Export Data
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'active_sessions.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/active_sessions.php">
          <i class="fa-solid fa-user-clock me-2"></i>Active Sessions
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'backup.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/admin/backup.php">
          <i class="fa-solid fa-database me-2"></i>Database Backup
        </a>
      </li>
      <?php endif; ?>
      <li class="nav-item">
        <a class="nav-link <?= $currentPage === 'profile.php' ? 'fw-semibold text-primary' : 'text-secondary' ?>" href="<?= APP_URL ?>/profile.php">
          <i class="fa-solid fa-id-card me-2"></i>My Profile
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-danger" href="<?= APP_URL ?>/logout.php">
          <i class="fa-solid fa-right-from-bracket me-2"></i>Logout
        </a>
      </li>
    </ul>
  </div>
</div>
