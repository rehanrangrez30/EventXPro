<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg sticky-top eventx-navbar">
  <div class="container">
    <a class="navbar-brand fw-bold d-flex align-items-center" href="<?= APP_URL ?>/index.php">
      <img src="<?= APP_URL ?>/assets/images/icons/logo-nav.png" alt="<?= APP_NAME ?>" width="44" height="44" class="me-2">
      <?= APP_NAME ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#eventxNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="eventxNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <li class="nav-item"><a class="nav-link <?= $currentPage === 'index.php' ? 'active' : '' ?>" href="<?= APP_URL ?>/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/events.php">Events</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/contact.php">Contact</a></li>

        <?php if (is_logged_in()): ?>
          <?php
            $unreadStmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
            $unreadStmt->execute([$_SESSION['user_id']]);
            $unreadCount = (int) $unreadStmt->fetchColumn();
          ?>
          <li class="nav-item">
            <a class="nav-link position-relative" href="<?= APP_URL ?>/notifications.php" title="Notifications">
              <i class="fa-solid fa-bell"></i>
              <?php if ($unreadCount > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:.6rem;"><?= $unreadCount ?></span>
              <?php endif; ?>
            </a>
          </li>
          <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/<?= sanitize($_SESSION['role_name']) ?>/dashboard.php">Dashboard</a></li>
          <li class="nav-item"><a class="btn btn-outline-danger btn-sm ms-lg-2" href="<?= APP_URL ?>/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/login.php">Login</a></li>
          <li class="nav-item"><a class="btn btn-primary btn-sm ms-lg-2" href="<?= APP_URL ?>/register.php">Register</a></li>
        <?php endif; ?>

        <li class="nav-item ms-lg-2">
          <button id="darkModeToggle" class="btn btn-sm btn-outline-secondary" aria-label="Toggle dark mode">
            <i class="fa-solid fa-moon"></i>
          </button>
        </li>
      </ul>
    </div>
  </div>
</nav>
