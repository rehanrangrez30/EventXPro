<?php
/**
 * EventX Pro - Central Error Handling & Logging
 *
 * Hooked into config.php so every page benefits automatically. Errors are
 * written to logs/error.log and security-relevant failures to
 * logs/security.log. In development the friendly page still shows, but
 * technical detail is available in the logs rather than on screen, matching
 * the "never expose SQL/paths to users" rule used throughout the project.
 */

define('LOG_DIR', __DIR__ . '/../logs');

function eventx_write_log(string $file, string $message): void
{
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    @file_put_contents(LOG_DIR . '/' . $file, $line, FILE_APPEND);
}

function eventx_log_error(string $message): void
{
    eventx_write_log('error.log', $message);
}

function eventx_log_security(string $message): void
{
    eventx_write_log('security.log', $message);
}

/**
 * Converts PHP warnings/notices into logged entries instead of on-page
 * output, without interrupting execution (matches PHP's default warning
 * behavior but keeps the browser clean).
 */
set_error_handler(function ($severity, $message, $file, $line) {
    eventx_log_error("PHP Error [$severity]: $message in $file:$line");
    return true; // suppress default on-screen output
});

/**
 * Catches anything that slips through as an uncaught exception (e.g. a
 * PDOException that wasn't wrapped in try/catch) and shows the friendly
 * 500 page instead of a raw stack trace.
 */
set_exception_handler(function (Throwable $e) {
    eventx_log_error('Uncaught Exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    $errorPageDir = defined('APP_URL') ? rtrim(__DIR__ . '/../errors/500.php', '/') : null;
    if (file_exists(__DIR__ . '/../errors/500.php')) {
        require __DIR__ . '/../errors/500.php';
    } else {
        echo 'Something went wrong. Please try again later.';
    }
    exit;
});

/**
 * Catches fatal errors (out of memory, parse-time-safe fatals) on shutdown.
 */
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        eventx_log_error('Fatal Error: ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']);
    }
});
