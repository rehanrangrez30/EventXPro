<div id="eventxChatbot" class="eventx-chatbot">
  <button id="chatbotToggle" class="chatbot-toggle" title="Chat with EventX Assistant">
    <i class="fa-solid fa-comment-dots"></i>
  </button>

  <div id="chatbotWindow" class="chatbot-window d-none">
    <div class="chatbot-header">
      <span><i class="fa-solid fa-robot me-2"></i>EventX Assistant</span>
      <button id="chatbotClose" class="btn-close btn-close-white" aria-label="Close"></button>
    </div>
    <div id="chatbotMessages" class="chatbot-messages">
      <div class="chatbot-msg chatbot-msg-bot">
        Hi! I'm the EventX Pro assistant. Ask me about event registration, deadlines, certificates, or logging in.
      </div>
    </div>
    <form id="chatbotForm" class="chatbot-input-row">
      <input type="text" id="chatbotInput" class="form-control form-control-sm" placeholder="Type a question..." autocomplete="off">
      <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-paper-plane"></i></button>
    </form>
  </div>
</div>

<script src="<?= APP_URL ?>/assets/js/chatbot.js" data-endpoint="<?= APP_URL ?>/chatbot_api.php"></script>
