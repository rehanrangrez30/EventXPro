<div id="pwaInstallBanner" class="ex-install-banner d-none">
    <div class="d-flex align-items-center gap-2">
        <img src="<?= APP_URL ?>/assets/images/icons/icon-192.png" alt="" width="36" height="36" style="border-radius:8px;">
        <div>
            <div class="fw-semibold small">Install EventX Pro</div>
            <div class="text-secondary" style="font-size:.75rem;">Add to your home screen for quick access</div>
        </div>
    </div>
    <div class="d-flex gap-2">
        <button id="pwaInstallDismiss" class="btn btn-sm btn-outline-secondary" aria-label="Dismiss">✕</button>
        <button id="pwaInstallAccept" class="btn btn-sm btn-primary">Install</button>
    </div>
</div>
