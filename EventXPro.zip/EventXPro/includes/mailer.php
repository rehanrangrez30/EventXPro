<?php
/**
 * EventX Pro - Dependency-Free SMTP Mailer
 *
 * A minimal SMTP client built on PHP's native stream sockets. No
 * Composer/PHPMailer dependency, so it works on a stock XAMPP install.
 * Supports STARTTLS (port 587, e.g. Gmail) and optional file attachments.
 *
 * Every call is wrapped by the caller in a try/catch and failures are
 * only logged — a broken/unconfigured SMTP setup must never block
 * registration or certificate generation, since email here is a
 * bonus notification, not a core requirement.
 */

class EventXMailer
{
    /**
     * @param array{path:string,name:string}[] $attachments
     */
    public static function send(string $toEmail, string $toName, string $subject, string $htmlBody, array $attachments = []): bool
    {
        if (!EMAIL_ENABLED) {
            return false;
        }

        $socket = @stream_socket_client(
            'tcp://' . SMTP_HOST . ':' . SMTP_PORT,
            $errno,
            $errstr,
            10
        );
        if (!$socket) {
            error_log('SMTP connect failed: ' . $errstr);
            return false;
        }

        try {
            self::expect($socket, '220');
            self::command($socket, 'EHLO ' . SMTP_HOST, '250');

            if (SMTP_PORT == 587) {
                self::command($socket, 'STARTTLS', '220');
                if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new Exception('STARTTLS negotiation failed');
                }
                self::command($socket, 'EHLO ' . SMTP_HOST, '250');
            }

            self::command($socket, 'AUTH LOGIN', '334');
            self::command($socket, base64_encode(SMTP_USER), '334');
            self::command($socket, base64_encode(SMTP_PASS), '235');

            self::command($socket, 'MAIL FROM:<' . SMTP_FROM_EMAIL . '>', '250');
            self::command($socket, 'RCPT TO:<' . $toEmail . '>', '250');
            self::command($socket, 'DATA', '354');

            $boundary = 'eventx-' . bin2hex(random_bytes(8));
            $headers = self::buildHeaders($toEmail, $toName, $subject, $boundary, !empty($attachments));
            $body = self::buildBody($htmlBody, $boundary, $attachments);

            fwrite($socket, $headers . "\r\n" . $body . "\r\n.\r\n");
            self::expect($socket, '250');

            self::command($socket, 'QUIT', '221');
            fclose($socket);
            return true;
        } catch (Exception $e) {
            error_log('SMTP send failed: ' . $e->getMessage());
            @fclose($socket);
            return false;
        }
    }

    private static function buildHeaders(string $toEmail, string $toName, string $subject, string $boundary, bool $hasAttachments): string
    {
        $lines = [
            'From: ' . SMTP_FROM_NAME . ' <' . SMTP_FROM_EMAIL . '>',
            'To: ' . $toName . ' <' . $toEmail . '>',
            'Subject: ' . self::encodeHeader($subject),
            'MIME-Version: 1.0',
            'Date: ' . date('r'),
        ];
        $lines[] = $hasAttachments
            ? 'Content-Type: multipart/mixed; boundary="' . $boundary . '"'
            : 'Content-Type: text/html; charset=UTF-8';
        return implode("\r\n", $lines) . "\r\n";
    }

    private static function buildBody(string $htmlBody, string $boundary, array $attachments): string
    {
        if (empty($attachments)) {
            return $htmlBody;
        }

        $parts = "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n" . $htmlBody . "\r\n";

        foreach ($attachments as $file) {
            if (!is_readable($file['path'])) {
                continue;
            }
            $data = chunk_split(base64_encode(file_get_contents($file['path'])));
            $parts .= "--$boundary\r\n"
                . "Content-Type: application/octet-stream; name=\"{$file['name']}\"\r\n"
                . "Content-Transfer-Encoding: base64\r\n"
                . "Content-Disposition: attachment; filename=\"{$file['name']}\"\r\n\r\n"
                . $data . "\r\n";
        }
        $parts .= "--$boundary--";
        return $parts;
    }

    private static function encodeHeader(string $text): string
    {
        return '=?UTF-8?B?' . base64_encode($text) . '?=';
    }

    private static function command($socket, string $cmd, string $expectedCode): void
    {
        fwrite($socket, $cmd . "\r\n");
        self::expect($socket, $expectedCode);
    }

    private static function expect($socket, string $expectedCode): void
    {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            // Multi-line SMTP responses use "code-" until the final "code ".
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        if (strpos($response, $expectedCode) !== 0) {
            throw new Exception("Unexpected SMTP response (wanted $expectedCode): $response");
        }
    }
}

/**
 * Convenience wrapper matching the project's existing helper style
 * (see notify_user() in functions.php). Always safe to call even if
 * email isn't configured — silently returns false.
 */
function send_mail(string $toEmail, string $toName, string $subject, string $htmlBody, array $attachments = []): bool
{
    try {
        return EventXMailer::send($toEmail, $toName, $subject, $htmlBody, $attachments);
    } catch (Throwable $e) {
        error_log('send_mail() error: ' . $e->getMessage());
        return false;
    }
}
