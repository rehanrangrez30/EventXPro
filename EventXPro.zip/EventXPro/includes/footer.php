<footer class="eventx-footer">
  <div class="container py-5">
    <div class="row g-4">
      <div class="col-md-4">
        <h5 class="fw-bold mb-3 d-flex align-items-center">
          <img src="<?= APP_URL ?>/assets/images/icons/logo-nav.png" alt="<?= APP_NAME ?>" width="36" height="36" class="me-2">
          <?= APP_NAME ?>
        </h5>
        <p class="text-secondary small"><?= APP_TAGLINE ?>. Digitally managing the complete lifecycle of college events — from proposal to certificate.</p>
      </div>
      <div class="col-md-2">
        <h6 class="fw-semibold mb-3">Explore</h6>
        <ul class="list-unstyled small">
          <li><a href="<?= APP_URL ?>/index.php">Home</a></li>
          <li><a href="<?= APP_URL ?>/events.php">Events</a></li>
          <li><a href="<?= APP_URL ?>/gallery.php">Gallery</a></li>
          <li><a href="<?= APP_URL ?>/about.php">About</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h6 class="fw-semibold mb-3">Account</h6>
        <ul class="list-unstyled small">
          <li><a href="<?= APP_URL ?>/login.php">Login</a></li>
          <li><a href="<?= APP_URL ?>/register.php">Register</a></li>
          <li><a href="<?= APP_URL ?>/contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6 class="fw-semibold mb-3">Contact</h6>
        <ul class="list-unstyled small">
          <li><i class="fa-solid fa-location-dot me-2"></i>College Campus, India</li>
          <li><i class="fa-solid fa-envelope me-2"></i>support@eventxpro.local</li>
        </ul>
      </div>
    </div>
    <hr class="border-secondary-subtle">
    <p class="text-center small text-secondary mb-0">&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.1/aos.js"></script>
<script>AOS.init({ duration: 700, once: true });</script>
<!-- Custom JS -->
<script>window.EVENTX_APP_URL = <?= json_encode(APP_URL) ?>;</script>
<script src="<?= APP_URL ?>/assets/js/main.js"></script>
<script src="<?= APP_URL ?>/assets/js/card-tilt.js"></script>
<script src="<?= APP_URL ?>/assets/js/auth-ui.js"></script>

<?php include __DIR__ . '/chatbot_widget.php'; ?>
</body>
</html>
