<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('faculty');

// Now backed by real per-faculty assignments (admin/manage_assignments.php).
$events = $pdo->prepare(
    "SELECT e.event_id, e.title, e.event_date, e.venue, u.full_name AS organizer_name,
            fa.responsibility_type, fa.assignment_status,
            (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id AND r.status = 'registered') AS registered_count
     FROM faculty_event_assignments fa
     JOIN events e ON fa.event_id = e.event_id
     LEFT JOIN users u ON e.organizer_id = u.user_id
     WHERE fa.faculty_id = ?
     ORDER BY e.event_date ASC"
);
$events->execute([$_SESSION['user_id']]);
$events = $events->fetchAll();

$pageTitle = 'Assigned Events';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">My Assigned Events</h4>
      <p class="text-secondary small mb-4">
        Events the administrator has assigned to you for supervision.
      </p>

      <?php if (empty($events)): ?>
        <div class="ex-card text-center py-5">
          <p class="text-secondary mb-0">You have no assigned events yet. Check back once the admin assigns you to one.</p>
        </div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Event</th>
                  <th>Date</th>
                  <th>Venue</th>
                  <th>Organizer</th>
                  <th>My Role</th>
                  <th class="pe-4">Registrations</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($events as $ev): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($ev['title']) ?></td>
                    <td><?= date('d M Y', strtotime($ev['event_date'])) ?></td>
                    <td><?= sanitize($ev['venue']) ?></td>
                    <td><?= sanitize($ev['organizer_name'] ?? 'N/A') ?></td>
                    <td class="text-capitalize"><?= sanitize($ev['responsibility_type']) ?></td>
                    <td class="pe-4"><?= (int) $ev['registered_count'] ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
