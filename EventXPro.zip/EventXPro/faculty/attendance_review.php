<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('faculty');

$assigned = $pdo->prepare(
    "SELECT e.event_id, e.title FROM faculty_event_assignments fa
     JOIN events e ON fa.event_id = e.event_id
     WHERE fa.faculty_id = ? AND fa.assignment_status != 'cancelled'
     ORDER BY e.event_date DESC"
);
$assigned->execute([$_SESSION['user_id']]);
$assignedEvents = $assigned->fetchAll();
$usingAssignments = !empty($assignedEvents);

if (!$usingAssignments) {
    // No assignments yet — fall back to all published/archived events so
    // faculty still have something meaningful to review.
    $assignedEvents = $pdo->query(
        "SELECT event_id, title FROM events WHERE status IN ('published','archived','completed')
         ORDER BY event_date DESC"
    )->fetchAll();
}

$eventId = (int) ($_GET['event_id'] ?? ($assignedEvents[0]['event_id'] ?? 0));

$records = [];
if ($eventId) {
    $stmt = $pdo->prepare(
        "SELECT r.registration_id, u.full_name, u.email,
                a.attendance_status, a.check_in_time
         FROM registrations r
         JOIN users u ON r.student_id = u.user_id
         LEFT JOIN attendance a ON a.registration_id = r.registration_id
         WHERE r.event_id = ? AND r.status = 'registered'
         ORDER BY u.full_name ASC"
    );
    $stmt->execute([$eventId]);
    $records = $stmt->fetchAll();
}

$pageTitle = 'Attendance Review';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-2">Attendance Review</h4>
      <?php if (!$usingAssignments): ?>
        <p class="text-secondary small mb-4">
          You have no formal event assignments yet, so all events are shown
          for oversight. Once an administrator assigns you to specific
          events, this list will narrow automatically.
        </p>
      <?php endif; ?>

      <?php if (empty($assignedEvents)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No events available to review.</p></div>
      <?php else: ?>
        <form method="GET" class="mb-4">
          <select name="event_id" class="form-select" onchange="this.form.submit()">
            <?php foreach ($assignedEvents as $ev): ?>
              <option value="<?= $ev['event_id'] ?>" <?= $eventId === (int) $ev['event_id'] ? 'selected' : '' ?>>
                <?= sanitize($ev['title']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>

        <?php if (empty($records)): ?>
          <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No registered participants for this event.</p></div>
        <?php else: ?>
          <div class="ex-card p-0">
            <div class="table-responsive">
              <table class="table align-middle mb-0">
                <thead>
                  <tr>
                    <th class="ps-4">Student</th>
                    <th>Email</th>
                    <th>Attendance</th>
                    <th class="pe-4">Check-in Time</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($records as $r): ?>
                    <tr>
                      <td class="ps-4"><?= sanitize($r['full_name']) ?></td>
                      <td><?= sanitize($r['email']) ?></td>
                      <td>
                        <span class="badge <?= $r['attendance_status'] === 'present' ? 'text-bg-success' : 'text-bg-secondary' ?> text-capitalize">
                          <?= sanitize($r['attendance_status'] ?? 'not marked') ?>
                        </span>
                      </td>
                      <td class="pe-4"><?= $r['check_in_time'] ? date('d M Y, h:i A', strtotime($r['check_in_time'])) : '—' ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
