<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('organizer');

$eventId = (int) ($_GET['event_id'] ?? 0);

// List organizer's past/ongoing events (attendance only makes sense on or after the event date).
$myEvents = $pdo->prepare(
    "SELECT event_id, title, event_date FROM events
     WHERE organizer_id = ? AND status IN ('published','archived') AND event_date <= CURDATE()
     ORDER BY event_date DESC"
);
$myEvents->execute([$_SESSION['user_id']]);
$eventOptions = $myEvents->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registration_id'], $_POST['event_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('organizer/attendance.php?event_id=' . (int) $_POST['event_id']);
    }

    $eventId = (int) $_POST['event_id'];
    $owns = $pdo->prepare('SELECT event_id FROM events WHERE event_id = ? AND organizer_id = ?');
    $owns->execute([$eventId, $_SESSION['user_id']]);
    if (!$owns->fetch()) {
        set_flash('danger', 'You do not have permission to mark attendance for this event.');
        redirect('organizer/attendance.php');
    }

    $regId = (int) $_POST['registration_id'];
    $status = $_POST['status'] === 'present' ? 'present' : 'absent';

    $reg = $pdo->prepare('SELECT student_id FROM registrations WHERE registration_id = ? AND event_id = ?');
    $reg->execute([$regId, $eventId]);
    $regRow = $reg->fetch();

    if ($regRow) {
        $upsert = $pdo->prepare(
            'INSERT INTO attendance (registration_id, event_id, student_id, attendance_status, check_in_time, marked_by)
             VALUES (?, ?, ?, ?, NOW(), ?)
             ON DUPLICATE KEY UPDATE attendance_status = VALUES(attendance_status), check_in_time = VALUES(check_in_time), marked_by = VALUES(marked_by)'
        );
        $upsert->execute([$regId, $eventId, $regRow['student_id'], $status, $_SESSION['user_id']]);
    }

    redirect('organizer/attendance.php?event_id=' . $eventId);
}

$participants = [];
$currentEvent = null;
if ($eventId > 0) {
    $owns = $pdo->prepare('SELECT event_id, title FROM events WHERE event_id = ? AND organizer_id = ?');
    $owns->execute([$eventId, $_SESSION['user_id']]);
    $currentEvent = $owns->fetch();

    if ($currentEvent) {
        $stmt = $pdo->prepare(
            "SELECT r.registration_id, u.full_name, u.email,
                    COALESCE(a.attendance_status, 'absent') AS attendance_status
             FROM registrations r
             JOIN users u ON r.student_id = u.user_id
             LEFT JOIN attendance a ON a.registration_id = r.registration_id
             WHERE r.event_id = ? AND r.status = 'registered'
             ORDER BY u.full_name ASC"
        );
        $stmt->execute([$eventId]);
        $participants = $stmt->fetchAll();
    }
}

$pageTitle = 'Attendance';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Mark Attendance</h4>

      <div class="ex-card mb-4">
        <form method="GET" class="row g-2">
          <div class="col-md-9">
            <select name="event_id" class="form-select" onchange="this.form.submit()">
              <option value="0">Select an event...</option>
              <?php foreach ($eventOptions as $ev): ?>
                <option value="<?= $ev['event_id'] ?>" <?= $eventId === (int) $ev['event_id'] ? 'selected' : '' ?>>
                  <?= sanitize($ev['title']) ?> — <?= date('d M Y', strtotime($ev['event_date'])) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3">
            <button type="submit" class="btn btn-outline-primary w-100">Load</button>
          </div>
        </form>
        <?php if (empty($eventOptions)): ?>
          <p class="text-secondary small mt-3 mb-0">Attendance opens once one of your published events reaches its event date.</p>
        <?php endif; ?>
      </div>

      <?php if (!empty($currentEvent)): ?>
      <div class="ex-card mb-4 text-center">
        <h6 class="fw-semibold mb-2"><i class="fa-solid fa-qrcode text-primary me-1"></i>QR Self Check-in</h6>
        <p class="text-secondary small mb-3">
          Display this code at the venue. Students scan it with their phone
          (already logged in) to mark themselves present instantly — no
          manual list needed at the door.
        </p>
        <div id="checkinQr" class="d-flex justify-content-center mb-2"></div>
        <p class="small text-secondary mb-0"><code><?= APP_URL ?>/checkin.php?event_id=<?= $eventId ?></code></p>
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
      <script>
        new QRCode(document.getElementById("checkinQr"), {
          text: "<?= APP_URL ?>/checkin.php?event_id=<?= $eventId ?>",
          width: 180, height: 180,
        });
      </script>
      <?php endif; ?>

      <?php if ($eventId > 0 && empty($participants) && !empty($eventOptions)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No registered participants for this event yet.</p></div>
      <?php elseif (!empty($participants)): ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Participant</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th class="text-end pe-4">Mark</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($participants as $p): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($p['full_name']) ?></td>
                    <td><?= sanitize($p['email']) ?></td>
                    <td>
                      <span class="badge <?= $p['attendance_status'] === 'present' ? 'text-bg-success' : 'text-bg-secondary' ?> text-capitalize">
                        <?= sanitize($p['attendance_status']) ?>
                      </span>
                    </td>
                    <td class="text-end pe-4">
                      <form method="POST" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="event_id" value="<?= $eventId ?>">
                        <input type="hidden" name="registration_id" value="<?= $p['registration_id'] ?>">
                        <button type="submit" name="status" value="present" class="btn btn-sm btn-outline-success">Present</button>
                        <button type="submit" name="status" value="absent" class="btn btn-sm btn-outline-secondary">Absent</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
