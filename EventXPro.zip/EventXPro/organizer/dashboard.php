<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('organizer');

$myActivity = $pdo->prepare(
    "SELECT action, description, created_at FROM activity_logs
     WHERE user_id = ? ORDER BY created_at DESC LIMIT 6"
);
$myActivity->execute([$_SESSION['user_id']]);
$logs = $myActivity->fetchAll();

$eventsCreated = $pdo->prepare("SELECT COUNT(*) FROM events WHERE organizer_id = ?");
$eventsCreated->execute([$_SESSION['user_id']]);
$totalEvents = (int) $eventsCreated->fetchColumn();

$totalRegs = $pdo->prepare(
    "SELECT COUNT(*) FROM registrations r JOIN events e ON r.event_id = e.event_id
     WHERE e.organizer_id = ? AND r.status = 'registered'"
);
$totalRegs->execute([$_SESSION['user_id']]);
$registrationCount = (int) $totalRegs->fetchColumn();

$draftCount = $pdo->prepare("SELECT COUNT(*) FROM events WHERE organizer_id = ? AND status = 'draft'");
$draftCount->execute([$_SESSION['user_id']]);
$pendingDrafts = (int) $draftCount->fetchColumn();

$pageTitle = 'Organizer Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Welcome, <?= sanitize($_SESSION['full_name']) ?> 👋</h4>

      <div class="row g-3 mb-4">
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $totalEvents ?></div>
            <div class="text-secondary small">Events Created</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $registrationCount ?></div>
            <div class="text-secondary small">Total Registrations</div>
          </div>
        </div>
        <div class="col-md-4 col-6">
          <div class="ex-card text-center">
            <div class="ex-stat-number"><?= $pendingDrafts ?></div>
            <div class="text-secondary small">Drafts to Publish</div>
          </div>
        </div>
      </div>

      <div class="ex-card mb-4">
        <h6 class="fw-semibold mb-2">Event Management</h6>
        <p class="text-secondary small mb-3">
          Create and publish events, then track registrations from one place.
        </p>
        <a href="<?= APP_URL ?>/organizer/manage_events.php" class="btn btn-sm btn-primary">Manage Events</a>
        <a href="<?= APP_URL ?>/organizer/event_form.php" class="btn btn-sm btn-outline-primary">Create New Event</a>
      </div>

      <div class="ex-card">
        <h6 class="fw-semibold mb-3">My Recent Activity</h6>
        <?php if (empty($logs)): ?>
          <p class="text-secondary small mb-0">No activity recorded yet.</p>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($logs as $log): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                <span><?= sanitize($log['description'] ?? $log['action']) ?></span>
                <span class="text-secondary small"><?= date('d M, H:i', strtotime($log['created_at'])) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
