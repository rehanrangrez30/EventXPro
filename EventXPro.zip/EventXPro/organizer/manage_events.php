<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('organizer');

// Handle status actions (publish / cancel / archive / delete) for this organizer's own events only.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['event_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('organizer/manage_events.php');
    }

    $eventId = (int) $_POST['event_id'];
    $owns = $pdo->prepare('SELECT event_id, title FROM events WHERE event_id = ? AND organizer_id = ?');
    $owns->execute([$eventId, $_SESSION['user_id']]);
    $ownedEvent = $owns->fetch();

    if (!$ownedEvent) {
        set_flash('danger', 'Event not found or you do not have permission to modify it.');
        redirect('organizer/manage_events.php');
    }

    $action = $_POST['action'];
    $validActions = ['publish' => 'published', 'unpublish' => 'draft', 'cancel' => 'cancelled', 'archive' => 'archived'];

    if ($action === 'delete') {
        $del = $pdo->prepare('DELETE FROM events WHERE event_id = ?');
        $del->execute([$eventId]);
        set_flash('success', 'Event "' . $ownedEvent['title'] . '" was deleted.');
    } elseif (isset($validActions[$action])) {
        $upd = $pdo->prepare('UPDATE events SET status = ? WHERE event_id = ?');
        $upd->execute([$validActions[$action], $eventId]);
        set_flash('success', 'Event "' . $ownedEvent['title'] . '" is now ' . $validActions[$action] . '.');
    }

    $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
    $logStmt->execute([$_SESSION['user_id'], 'event_' . $action, $ownedEvent['title'], $_SERVER['REMOTE_ADDR'] ?? null]);

    redirect('organizer/manage_events.php');
}

$events = $pdo->prepare(
    "SELECT e.event_id, e.title, e.event_date, e.status, e.max_participants,
            (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id AND r.status = 'registered') AS registered_count
     FROM events e WHERE e.organizer_id = ? ORDER BY e.event_date DESC"
);
$events->execute([$_SESSION['user_id']]);
$myEvents = $events->fetchAll();

$pageTitle = 'Manage Events';
include __DIR__ . '/../includes/header.php';

$statusBadge = [
    'draft'     => 'text-bg-secondary',
    'published' => 'text-bg-success',
    'cancelled' => 'text-bg-danger',
    'archived'  => 'text-bg-dark',
];
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">Manage Events</h4>
        <a href="<?= APP_URL ?>/organizer/event_form.php" class="btn btn-primary">
          <i class="fa-solid fa-plus me-1"></i>Create Event
        </a>
      </div>

      <?php if (empty($myEvents)): ?>
        <div class="ex-card text-center py-5">
          <i class="fa-regular fa-calendar-plus fa-2x text-secondary mb-3"></i>
          <p class="text-secondary mb-0">You haven't created any events yet.</p>
        </div>
      <?php else: ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Title</th>
                  <th>Date</th>
                  <th>Registrations</th>
                  <th>Status</th>
                  <th class="text-end pe-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($myEvents as $ev): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($ev['title']) ?></td>
                    <td><?= date('d M Y', strtotime($ev['event_date'])) ?></td>
                    <td><?= (int) $ev['registered_count'] ?><?= $ev['max_participants'] > 0 ? ' / ' . (int) $ev['max_participants'] : '' ?></td>
                    <td><span class="badge <?= $statusBadge[$ev['status']] ?? 'text-bg-secondary' ?> text-capitalize"><?= sanitize($ev['status']) ?></span></td>
                    <td class="text-end pe-4">
                      <a href="<?= APP_URL ?>/organizer/event_form.php?id=<?= $ev['event_id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>

                      <?php if ($ev['status'] !== 'published'): ?>
                        <form method="POST" class="d-inline">
                          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                          <input type="hidden" name="event_id" value="<?= $ev['event_id'] ?>">
                          <button type="submit" name="action" value="publish" class="btn btn-sm btn-outline-success">Publish</button>
                        </form>
                      <?php else: ?>
                        <form method="POST" class="d-inline">
                          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                          <input type="hidden" name="event_id" value="<?= $ev['event_id'] ?>">
                          <button type="submit" name="action" value="cancel" class="btn btn-sm btn-outline-warning">Cancel</button>
                        </form>
                      <?php endif; ?>

                      <form method="POST" class="d-inline" onsubmit="return confirm('Delete this event permanently? This cannot be undone.');">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="event_id" value="<?= $ev['event_id'] ?>">
                        <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
