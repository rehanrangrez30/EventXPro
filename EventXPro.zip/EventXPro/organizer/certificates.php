<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('organizer');

$eventId = (int) ($_GET['event_id'] ?? 0);

$myEvents = $pdo->prepare(
    "SELECT event_id, title FROM events WHERE organizer_id = ? AND event_date <= CURDATE() ORDER BY event_date DESC"
);
$myEvents->execute([$_SESSION['user_id']]);
$eventOptions = $myEvents->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registration_id'], $_POST['event_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect('organizer/certificates.php?event_id=' . (int) $_POST['event_id']);
    }

    $eventId = (int) $_POST['event_id'];
    $regId = (int) $_POST['registration_id'];

    $owns = $pdo->prepare('SELECT event_id FROM events WHERE event_id = ? AND organizer_id = ?');
    $owns->execute([$eventId, $_SESSION['user_id']]);
    if (!$owns->fetch()) {
        set_flash('danger', 'You do not have permission for this event.');
        redirect('organizer/certificates.php');
    }

    $reg = $pdo->prepare(
        "SELECT r.student_id FROM registrations r
         JOIN attendance a ON a.registration_id = r.registration_id
         WHERE r.registration_id = ? AND r.event_id = ? AND a.attendance_status = 'present'"
    );
    $reg->execute([$regId, $eventId]);
    $regRow = $reg->fetch();

    if (!$regRow) {
        set_flash('danger', 'Certificates can only be generated for participants marked present.');
        redirect('organizer/certificates.php?event_id=' . $eventId);
    }

    $certNumber = 'EVX-CERT-' . date('Y') . '-' . str_pad((string) $regId, 6, '0', STR_PAD_LEFT);
    $verifyCode = bin2hex(random_bytes(12));

    try {
        $insert = $pdo->prepare(
            'INSERT INTO certificates (registration_id, student_id, event_id, certificate_number, verification_code, generated_by)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $insert->execute([$regId, $regRow['student_id'], $eventId, $certNumber, $verifyCode, $_SESSION['user_id']]);

        // Generate the downloadable PDF file (dependency-free writer).
        require_once __DIR__ . '/../includes/pdf_lib.php';
        $studentInfo = $pdo->prepare('SELECT full_name FROM users WHERE user_id = ?');
        $studentInfo->execute([$regRow['student_id']]);
        $studentName = $studentInfo->fetchColumn() ?: 'Participant';

        $eventInfo = $pdo->prepare('SELECT title, event_date FROM events WHERE event_id = ?');
        $eventInfo->execute([$eventId]);
        $eventInfo = $eventInfo->fetch();

        $relativePath = 'assets/uploads/certificates/' . $certNumber . '.pdf';
        $absolutePath = __DIR__ . '/../' . $relativePath;

        eventx_generate_certificate_pdf($absolutePath, [
            'student_name'       => $studentName,
            'event_title'        => $eventInfo['title'] ?? '',
            'event_date'         => $eventInfo ? date('d M Y', strtotime($eventInfo['event_date'])) : '',
            'certificate_number' => $certNumber,
            'verification_code'  => $verifyCode,
        ]);

        $pdo->prepare('UPDATE certificates SET pdf_path = ? WHERE registration_id = ?')
            ->execute([$relativePath, $regId]);

        notify_user($pdo, $regRow['student_id'], 'Certificate Ready', 'Your certificate for this event is now available.', 'certificate', $eventId, 'student/certificates.php');

        // Best-effort certificate email with the PDF attached — never
        // blocks certificate generation if SMTP isn't configured.
        require_once __DIR__ . '/../includes/mailer.php';
        require_once __DIR__ . '/../includes/email_templates.php';
        $studentEmail = $pdo->prepare('SELECT email FROM users WHERE user_id = ?');
        $studentEmail->execute([$regRow['student_id']]);
        $studentEmail = $studentEmail->fetchColumn();

        if ($studentEmail) {
            send_mail(
                $studentEmail,
                $studentName,
                'Your Certificate: ' . ($eventInfo['title'] ?? ''),
                eventx_certificate_email_body(
                    $studentName,
                    $eventInfo['title'] ?? '',
                    $certNumber,
                    APP_URL . '/certificate_verify.php?code=' . urlencode($verifyCode)
                ),
                [['path' => $absolutePath, 'name' => $certNumber . '.pdf']]
            );
        }

        set_flash('success', 'Certificate ' . $certNumber . ' generated.');
    } catch (PDOException $e) {
        set_flash('danger', 'A certificate for this registration already exists.');
    }
    redirect('organizer/certificates.php?event_id=' . $eventId);
}

$eligible = [];
if ($eventId > 0) {
    $stmt = $pdo->prepare(
        "SELECT r.registration_id, u.full_name, u.email, c.certificate_number
         FROM registrations r
         JOIN attendance a ON a.registration_id = r.registration_id AND a.attendance_status = 'present'
         JOIN users u ON r.student_id = u.user_id
         LEFT JOIN certificates c ON c.registration_id = r.registration_id
         WHERE r.event_id = ? AND r.status = 'registered'
         ORDER BY u.full_name ASC"
    );
    $stmt->execute([$eventId]);
    $eligible = $stmt->fetchAll();
}

$pageTitle = 'Certificates';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <h4 class="fw-bold mb-4">Generate Certificates</h4>

      <div class="ex-card mb-4">
        <form method="GET" class="row g-2">
          <div class="col-md-9">
            <select name="event_id" class="form-select" onchange="this.form.submit()">
              <option value="0">Select an event...</option>
              <?php foreach ($eventOptions as $ev): ?>
                <option value="<?= $ev['event_id'] ?>" <?= $eventId === (int) $ev['event_id'] ? 'selected' : '' ?>><?= sanitize($ev['title']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3"><button type="submit" class="btn btn-outline-primary w-100">Load</button></div>
        </form>
      </div>

      <?php if ($eventId > 0 && empty($eligible)): ?>
        <div class="ex-card text-center py-5"><p class="text-secondary mb-0">No participants marked present yet. Mark attendance first.</p></div>
      <?php elseif (!empty($eligible)): ?>
        <div class="ex-card p-0">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th class="ps-4">Participant</th>
                  <th>Certificate No.</th>
                  <th class="text-end pe-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($eligible as $el): ?>
                  <tr>
                    <td class="ps-4"><?= sanitize($el['full_name']) ?></td>
                    <td><?= $el['certificate_number'] ? sanitize($el['certificate_number']) : '<span class="text-secondary">Not generated</span>' ?></td>
                    <td class="text-end pe-4">
                      <?php if (!$el['certificate_number']): ?>
                        <form method="POST" class="d-inline">
                          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                          <input type="hidden" name="event_id" value="<?= $eventId ?>">
                          <input type="hidden" name="registration_id" value="<?= $el['registration_id'] ?>">
                          <button type="submit" class="btn btn-sm btn-primary">Generate</button>
                        </form>
                      <?php else: ?>
                        <span class="badge text-bg-success">Issued</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
