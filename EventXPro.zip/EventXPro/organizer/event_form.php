<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('organizer');

$eventId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$isEdit = $eventId > 0;

$old = [
    'title' => '', 'category_id' => '', 'description' => '', 'event_date' => '',
    'start_time' => '', 'end_time' => '', 'venue' => '', 'max_participants' => '',
    'registration_deadline' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM events WHERE event_id = ? AND organizer_id = ?');
    $stmt->execute([$eventId, $_SESSION['user_id']]);
    $existing = $stmt->fetch();

    if (!$existing) {
        set_flash('danger', 'Event not found or you do not have permission to edit it.');
        redirect('organizer/manage_events.php');
    }
    $old = array_merge($old, $existing);
    $old['registration_deadline'] = date('Y-m-d\TH:i', strtotime($existing['registration_deadline']));
}

$categories = $pdo->query('SELECT category_id, category_name FROM event_categories WHERE is_active = 1')->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please try again.';
    }

    $old['title']                  = trim($_POST['title'] ?? '');
    $old['category_id']            = (int) ($_POST['category_id'] ?? 0);
    $old['description']             = trim($_POST['description'] ?? '');
    $old['event_date']              = $_POST['event_date'] ?? '';
    $old['start_time']              = $_POST['start_time'] ?? '';
    $old['end_time']                = $_POST['end_time'] ?? '';
    $old['venue']                   = trim($_POST['venue'] ?? '');
    $old['max_participants']        = (int) ($_POST['max_participants'] ?? 0);
    $old['registration_deadline']   = $_POST['registration_deadline'] ?? '';

    if (strlen($old['title']) < 3) {
        $errors[] = 'Event title must be at least 3 characters.';
    }
    if (strlen($old['description']) < 10) {
        $errors[] = 'Please provide a meaningful event description (at least 10 characters).';
    }
    if (empty($old['event_date']) || strtotime($old['event_date']) < strtotime(date('Y-m-d'))) {
        $errors[] = 'Please choose a valid, upcoming event date.';
    }
    if (empty($old['start_time']) || empty($old['end_time']) || strtotime($old['end_time']) <= strtotime($old['start_time'])) {
        $errors[] = 'End time must be later than start time.';
    }
    if (empty($old['venue'])) {
        $errors[] = 'Venue is required.';
    }
    if ($old['max_participants'] < 0) {
        $errors[] = 'Maximum participants cannot be negative.';
    }
    if (empty($old['registration_deadline']) || strtotime($old['registration_deadline']) > strtotime($old['event_date'] . ' ' . $old['start_time'])) {
        $errors[] = 'Registration deadline must be before the event start time.';
    }

    if (empty($errors)) {
        $deadline = date('Y-m-d H:i:s', strtotime($old['registration_deadline']));

        if ($isEdit) {
            $update = $pdo->prepare(
                'UPDATE events SET category_id = ?, title = ?, description = ?, event_date = ?,
                 start_time = ?, end_time = ?, venue = ?, max_participants = ?, registration_deadline = ?
                 WHERE event_id = ? AND organizer_id = ?'
            );
            $update->execute([
                $old['category_id'] ?: null, $old['title'], $old['description'], $old['event_date'],
                $old['start_time'], $old['end_time'], $old['venue'], $old['max_participants'],
                $deadline, $eventId, $_SESSION['user_id'],
            ]);
            $action = 'event_updated';
        } else {
            $insert = $pdo->prepare(
                'INSERT INTO events (organizer_id, category_id, title, description, event_date, start_time,
                 end_time, venue, max_participants, registration_deadline, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "draft")'
            );
            $insert->execute([
                $_SESSION['user_id'], $old['category_id'] ?: null, $old['title'], $old['description'],
                $old['event_date'], $old['start_time'], $old['end_time'], $old['venue'],
                $old['max_participants'], $deadline,
            ]);
            $eventId = (int) $pdo->lastInsertId();
            $action = 'event_created';
        }

        $logStmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)');
        $logStmt->execute([$_SESSION['user_id'], $action, $old['title'], $_SERVER['REMOTE_ADDR'] ?? null]);

        set_flash('success', 'Event "' . $old['title'] . '" saved as draft. Publish it from Manage Events when ready.');
        redirect('organizer/manage_events.php');
    }
}

$pageTitle = $isEdit ? 'Edit Event' : 'Create Event';
include __DIR__ . '/../includes/header.php';
?>

<section class="container py-5">
  <div class="row">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="col-12 col-lg-9">
      <div class="ex-card">
        <h4 class="fw-bold mb-4"><?= $isEdit ? 'Edit Event' : 'Create New Event' ?></h4>

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= sanitize($e) ?></li><?php endforeach; ?></ul>
          </div>
        <?php endif; ?>

        <form method="POST" novalidate>
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

          <div class="mb-3">
            <label class="form-label">Event Title <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control" value="<?= sanitize($old['title']) ?>" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
              <option value="">— None —</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['category_id'] ?>" <?= (int) $old['category_id'] === (int) $cat['category_id'] ? 'selected' : '' ?>>
                  <?= sanitize($cat['category_name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Description <span class="text-danger">*</span></label>
            <textarea name="description" class="form-control" rows="4" required><?= sanitize($old['description']) ?></textarea>
          </div>

          <div class="row">
            <div class="col-md-4 mb-3">
              <label class="form-label">Event Date <span class="text-danger">*</span></label>
              <input type="date" name="event_date" class="form-control" value="<?= sanitize($old['event_date']) ?>" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Start Time <span class="text-danger">*</span></label>
              <input type="time" name="start_time" class="form-control" value="<?= sanitize($old['start_time']) ?>" required>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">End Time <span class="text-danger">*</span></label>
              <input type="time" name="end_time" class="form-control" value="<?= sanitize($old['end_time']) ?>" required>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Venue <span class="text-danger">*</span></label>
              <input type="text" name="venue" class="form-control" value="<?= sanitize($old['venue']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Max Participants <span class="text-secondary small">(0 = unlimited)</span></label>
              <input type="number" name="max_participants" class="form-control" min="0" value="<?= sanitize((string) $old['max_participants']) ?>">
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label">Registration Deadline <span class="text-danger">*</span></label>
            <input type="datetime-local" name="registration_deadline" class="form-control" value="<?= sanitize($old['registration_deadline']) ?>" required>
          </div>

          <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Save Changes' : 'Create Event' ?></button>
          <a href="<?= APP_URL ?>/organizer/manage_events.php" class="btn btn-outline-secondary">Cancel</a>
        </form>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
