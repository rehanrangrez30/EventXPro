/**
 * EventX Pro - Background Music Controller
 */
document.addEventListener('DOMContentLoaded', function () {
    const audio      = document.getElementById('bgAudio');
    const playBtn    = document.getElementById('bgPlayPause');
    const muteBtn    = document.getElementById('bgMute');
    const volume     = document.getElementById('bgVolume');
    const prompt      = document.getElementById('bgMusicPrompt');
    const enableBtn  = document.getElementById('bgMusicEnable');

    if (!audio) return;

    audio.volume = parseFloat(volume.value);

    function updatePlayIcon() {
        playBtn.innerHTML = audio.paused
            ? '<i class="fa-solid fa-play"></i>'
            : '<i class="fa-solid fa-pause"></i>';
    }

    function updateMuteIcon() {
        muteBtn.innerHTML = audio.muted
            ? '<i class="fa-solid fa-volume-xmark"></i>'
            : '<i class="fa-solid fa-volume-high"></i>';
    }

    // Attempt autoplay on load; if blocked by the browser, show a manual control.
    const attemptAutoplay = audio.play();
    if (attemptAutoplay !== undefined) {
        attemptAutoplay
            .then(updatePlayIcon)
            .catch(function () {
                prompt.classList.remove('d-none');
            });
    }

    playBtn.addEventListener('click', function () {
        if (audio.paused) {
            audio.play();
        } else {
            audio.pause();
        }
        updatePlayIcon();
    });

    muteBtn.addEventListener('click', function () {
        audio.muted = !audio.muted;
        updateMuteIcon();
    });

    volume.addEventListener('input', function () {
        audio.volume = parseFloat(volume.value);
        if (audio.volume === 0) {
            audio.muted = true;
        } else {
            audio.muted = false;
        }
        updateMuteIcon();
    });

    enableBtn.addEventListener('click', function () {
        audio.play().then(function () {
            prompt.classList.add('d-none');
            updatePlayIcon();
        });
    });
});

/**
 * Widget expand/collapse (Phase 21E visual upgrade only — purely UI,
 * does not touch playback logic above, which keeps working identically
 * whether the widget is expanded or collapsed).
 */
document.addEventListener('DOMContentLoaded', function () {
    const player  = document.getElementById('bgMusicPlayer');
    const toggle  = document.getElementById('bgMusicToggle');
    if (!player || !toggle) return;

    function setExpanded(expanded) {
        player.classList.toggle('is-expanded', expanded);
        toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    }

    toggle.addEventListener('click', function (e) {
        e.stopPropagation();
        setExpanded(!player.classList.contains('is-expanded'));
    });

    document.addEventListener('click', function (e) {
        if (!player.contains(e.target)) {
            setExpanded(false);
        }
    });
});
