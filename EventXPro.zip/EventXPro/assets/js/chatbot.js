/**
 * EventX Pro - Chatbot Widget Controller
 */
document.addEventListener('DOMContentLoaded', function () {
    const toggle   = document.getElementById('chatbotToggle');
    const win      = document.getElementById('chatbotWindow');
    const closeBtn = document.getElementById('chatbotClose');
    const form     = document.getElementById('chatbotForm');
    const input    = document.getElementById('chatbotInput');
    const messages = document.getElementById('chatbotMessages');
    const script   = document.currentScript || document.querySelector('script[data-endpoint]');
    const endpoint = script ? script.getAttribute('data-endpoint') : 'chatbot_api.php';

    if (!toggle || !win) return;

    toggle.addEventListener('click', () => win.classList.toggle('d-none'));
    closeBtn.addEventListener('click', () => win.classList.add('d-none'));

    function addMessage(text, who) {
        const el = document.createElement('div');
        el.className = 'chatbot-msg chatbot-msg-' + who;
        el.style.whiteSpace = 'pre-line';
        el.textContent = text;
        messages.appendChild(el);
        messages.scrollTop = messages.scrollHeight;
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const text = input.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        input.value = '';

        fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'message=' + encodeURIComponent(text),
        })
            .then((res) => res.json())
            .then((data) => addMessage(data.reply || 'Sorry, something went wrong.', 'bot'))
            .catch(() => addMessage('Sorry, I could not reach the server. Please try again.', 'bot'));
    });
});
