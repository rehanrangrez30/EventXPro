/**
 * EventX Pro - Auth Form Micro-interactions
 * Password show/hide + a loading spinner on submit. Both are cosmetic:
 * neither calls preventDefault(), so the form always submits normally
 * to the same PHP endpoint exactly as before.
 */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.ex-password-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const input = document.getElementById(btn.dataset.target);
            if (!input) return;
            const showing = input.type === 'text';
            input.type = showing ? 'password' : 'text';
            btn.innerHTML = showing
                ? '<i class="fa-regular fa-eye"></i>'
                : '<i class="fa-regular fa-eye-slash"></i>';
        });
    });

    document.querySelectorAll('form.ex-auth-form').forEach(function (form) {
        form.addEventListener('submit', function () {
            const btn = form.querySelector('button[type="submit"]');
            if (!btn || btn.classList.contains('ex-btn-loading')) return;
            const originalText = btn.innerHTML;
            btn.classList.add('ex-btn-loading');
            btn.innerHTML = '<span class="ex-btn-spinner"></span>' + originalText;
        });
    });
});
