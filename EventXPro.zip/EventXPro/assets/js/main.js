/**
 * EventX Pro - Global Frontend Behaviour
 */
document.addEventListener('DOMContentLoaded', function () {
    // ---------- Premium navbar: compact + opaque on scroll ----------
    const navbar = document.querySelector('.eventx-navbar');
    if (navbar) {
        const applyScrollState = () => {
            navbar.classList.toggle('is-scrolled', window.scrollY > 12);
        };
        applyScrollState();
        window.addEventListener('scroll', applyScrollState, { passive: true });
    }

    // ---------- Stat count-up (purely visual; animates to the real
    // server-rendered value in data-value, never invents numbers) ----------
    const counters = document.querySelectorAll('.ex-counter[data-value]');
    if (counters.length && 'IntersectionObserver' in window) {
        const animateCounter = (el) => {
            const target = parseInt(el.dataset.value, 10) || 0;
            const duration = 900;
            const start = performance.now();
            const step = (now) => {
                const progress = Math.min((now - start) / duration, 1);
                const eased = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.round(eased * target).toLocaleString();
                if (progress < 1) requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
        };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        counters.forEach((el) => observer.observe(el));
    }

    const root   = document.documentElement;
    const toggle = document.getElementById('darkModeToggle');

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + value + ';expires=' + date.toUTCString() + ';path=/';
    }

    // Theme is already correctly applied server-side (see includes/header.php)
    // to avoid a light-mode flash on every page load — JS here only keeps
    // the toggle icon in sync and handles the click.
    function updateToggleIcon(theme) {
        if (!toggle) return;
        toggle.innerHTML = theme === 'dark'
            ? '<i class="fa-solid fa-sun"></i>'
            : '<i class="fa-solid fa-moon"></i>';
    }
    updateToggleIcon(root.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light');

    if (toggle) {
        toggle.addEventListener('click', function () {
            const current = root.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light';
            const next = current === 'dark' ? 'light' : 'dark';
            root.setAttribute('data-bs-theme', next);
            setCookie('ex_theme', next, 365);
            updateToggleIcon(next);
        });
    }

    // ---------- PWA: service worker registration ----------
    if ('serviceWorker' in navigator && window.EVENTX_APP_URL) {
        window.addEventListener('load', function () {
            navigator.serviceWorker
                .register(window.EVENTX_APP_URL + '/sw.js', { scope: window.EVENTX_APP_URL + '/' })
                .catch(function () {
                    // Offline caching is a nice-to-have; silently skip if it fails.
                });
        });
    }

    // ---------- PWA: install prompt banner ----------
    const installBanner = document.getElementById('pwaInstallBanner');
    const installAccept  = document.getElementById('pwaInstallAccept');
    const installDismiss = document.getElementById('pwaInstallDismiss');
    let deferredInstallPrompt = null;

    window.addEventListener('beforeinstallprompt', function (event) {
        event.preventDefault();
        if (getCookie('ex_install_dismissed')) {
            return;
        }
        deferredInstallPrompt = event;
        if (installBanner) {
            installBanner.classList.remove('d-none');
        }
    });

    if (installAccept) {
        installAccept.addEventListener('click', function () {
            if (!deferredInstallPrompt) return;
            deferredInstallPrompt.prompt();
            deferredInstallPrompt.userChoice.finally(function () {
                deferredInstallPrompt = null;
                installBanner.classList.add('d-none');
            });
        });
    }

    if (installDismiss) {
        installDismiss.addEventListener('click', function () {
            installBanner.classList.add('d-none');
            setCookie('ex_install_dismissed', '1', 30);
        });
    }

    window.addEventListener('appinstalled', function () {
        if (installBanner) installBanner.classList.add('d-none');
    });
});
