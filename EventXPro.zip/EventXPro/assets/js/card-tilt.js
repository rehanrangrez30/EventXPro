/**
 * EventX Pro - CSS 3D Card Tilt
 *
 * Applies a subtle mouse-tracked 3D tilt to any element with the
 * `.ex-tilt` class (event cards, category tiles). Pure CSS transforms
 * (rotateX/rotateY via a perspective wrapper) — no Three.js/WebGL, so
 * it works identically on every browser/device without a graphics-
 * capability check, and costs nothing on pages that don't use it.
 *
 * Respects `prefers-reduced-motion` and is skipped entirely on
 * touch-primary devices (tilting makes no sense without a hover cursor).
 */
(function () {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isTouchPrimary = window.matchMedia('(hover: none), (pointer: coarse)').matches;

    if (prefersReducedMotion || isTouchPrimary) {
        return;
    }

    const MAX_TILT_DEG = 6; // subtle, not gimmicky

    document.addEventListener('DOMContentLoaded', function () {
        const cards = document.querySelectorAll('.ex-tilt');

        cards.forEach(function (card) {
            card.style.transformStyle = 'preserve-3d';

            card.addEventListener('mousemove', function (e) {
                const rect = card.getBoundingClientRect();
                const px = (e.clientX - rect.left) / rect.width;  // 0..1
                const py = (e.clientY - rect.top) / rect.height;  // 0..1

                const rotateY = (px - 0.5) * (MAX_TILT_DEG * 2);
                const rotateX = (0.5 - py) * (MAX_TILT_DEG * 2);

                card.style.transform =
                    `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
            });

            card.addEventListener('mouseleave', function () {
                card.style.transform = '';
            });
        });
    });
})();
